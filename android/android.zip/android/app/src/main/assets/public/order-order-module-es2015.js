(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-order-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>order</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n<div class=\"container\">\r\n\r\n  <h1 style=\"margin-top: 25px;\">\r\n    {{title}}\r\n  </h1>\r\n\r\n  <div class=\"row\" style=\"margin-top: 25px;\">\r\n    <div class=\"col-md-3\">\r\n      <input type=\"text\" class=\"form-control\" [(ngModel)]=\"studentName\" placeholder=\"Name\">\r\n    </div>\r\n    <div class=\"col-md-3\">\r\n      <input type=\"text\" class=\"form-control\" [(ngModel)]=\"studentAge\" placeholder=\"Age\">\r\n    </div>\r\n    <div class=\"col-md-3\">\r\n      <input type=\"text\" class=\"form-control\" [(ngModel)]=\"studentAddress\" placeholder=\"Address\">\r\n    </div>\r\n    <div class=\"col-md-3\">\r\n      <button type=\"button\" (click)=\"CreateRecord()\" [disabled]=\"!studentName || !studentAge || !studentAddress\" class=\"btn btn-primary\">+\r\n        Create Student</button>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\" style=\"margin-top: 25px;\">\r\n    <div class=\"col-md-3\">\r\n      <div class=\"card\" style=\"width: 18rem;\" *ngFor=\"let item of students\">\r\n        <div class=\"card-body\" *ngIf=\"!item.isEdit; else elseBlock\">\r\n          <h5 class=\"card-title\">{{item.Name}}</h5>\r\n          <h6 class=\"card-subtitle mb-2 text-muted\">Age: {{item.Age}} Years</h6>\r\n          <p class=\"card-text\">Address: {{item.Address}}</p>\r\n          <a  class=\"card-link\" (click)=\"EditRecord(item)\">Edit</a>\r\n          <a  class=\"card-link\" (click)=\"RemoveRecord(item.id)\">Delete</a>\r\n        </div>\r\n        <ng-template #elseBlock>\r\n          <div class=\"card-body\">\r\n            <h5 class=\"card-title\">Edit</h5>\r\n            <div class=\"form-group\">\r\n              <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                  <input type=\"text\" class=\"form-control\" [(ngModel)]=\"item.EditName\" placeholder=\"Edit Name\">\r\n                </div>\r\n                <div class=\"col-md-12\">\r\n                  <input type=\"text\" class=\"form-control\" [(ngModel)]=\"item.EditAge\" placeholder=\"Edit Age\">\r\n                </div>\r\n                <div class=\"col-md-12\">\r\n                  <input type=\"text\" class=\"form-control\" [(ngModel)]=\"item.EditAddress\" placeholder=\"Edit Address\">\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <a  class=\"card-link\" (click)=\"item.isEdit = false\">Cancel</a>\r\n            <a  class=\"card-link\" (click)=\"UpdateRecord(item)\">Update</a>\r\n          </div>\r\n        </ng-template>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/order/order-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/order/order-routing.module.ts ***!
  \***********************************************/
/*! exports provided: OrderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderPageRoutingModule", function() { return OrderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./order.page */ "./src/app/order/order.page.ts");




const routes = [
    {
        path: '',
        component: _order_page__WEBPACK_IMPORTED_MODULE_3__["OrderPage"]
    }
];
let OrderPageRoutingModule = class OrderPageRoutingModule {
};
OrderPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OrderPageRoutingModule);



/***/ }),

/***/ "./src/app/order/order.module.ts":
/*!***************************************!*\
  !*** ./src/app/order/order.module.ts ***!
  \***************************************/
/*! exports provided: OrderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderPageModule", function() { return OrderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-routing.module */ "./src/app/order/order-routing.module.ts");
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order.page */ "./src/app/order/order.page.ts");







let OrderPageModule = class OrderPageModule {
};
OrderPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _order_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderPageRoutingModule"]
        ],
        declarations: [_order_page__WEBPACK_IMPORTED_MODULE_6__["OrderPage"]]
    })
], OrderPageModule);



/***/ }),

/***/ "./src/app/order/order.page.scss":
/*!***************************************!*\
  !*** ./src/app/order/order.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVyL29yZGVyLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/order/order.page.ts":
/*!*************************************!*\
  !*** ./src/app/order/order.page.ts ***!
  \*************************************/
/*! exports provided: OrderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderPage", function() { return OrderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _nest_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @nest/core */ "./src/app/zNest/core/index.ts");



let OrderPage = class OrderPage {
    constructor(crudService) {
        this.crudService = crudService;
        this.title = 'Firestore CRUD Operations Students App';
    }
    ngOnInit() {
        this.crudService.read('Student').subscribe(data => {
            this.students = data.map(e => {
                return {
                    id: e.payload.doc.id,
                    isEdit: false,
                    Name: e.payload.doc.data()['Name'],
                    Age: e.payload.doc.data()['Age'],
                    Address: e.payload.doc.data()['Address'],
                };
            });
            console.log(this.students);
        });
    }
    CreateRecord() {
        let record = {};
        record['Name'] = this.studentName;
        record['Age'] = this.studentAge;
        record['Address'] = this.studentAddress;
        this.crudService.create('Student', record).then(resp => {
            this.studentName = "";
            this.studentAge = undefined;
            this.studentAddress = "";
            console.log(resp);
        })
            .catch(error => {
            console.log(error);
        });
    }
    RemoveRecord(rowID) {
        this.crudService.delete('Student', rowID);
    }
    EditRecord(record) {
        record.isEdit = true;
        record.EditName = record.Name;
        record.EditAge = record.Age;
        record.EditAddress = record.Address;
    }
    UpdateRecord(recordRow) {
        let record = {};
        record['Name'] = recordRow.EditName;
        record['Age'] = recordRow.EditAge;
        record['Address'] = recordRow.EditAddress;
        this.crudService.update('Student', recordRow.id, record);
        recordRow.isEdit = false;
    }
};
OrderPage.ctorParameters = () => [
    { type: _nest_core__WEBPACK_IMPORTED_MODULE_2__["FirestoreCrudService"] }
];
OrderPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-order',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./order.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./order.page.scss */ "./src/app/order/order.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_nest_core__WEBPACK_IMPORTED_MODULE_2__["FirestoreCrudService"]])
], OrderPage);



/***/ })

}]);
//# sourceMappingURL=order-order-module-es2015.js.map