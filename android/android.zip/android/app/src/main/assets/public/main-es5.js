function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js", "common", 0],
      "./ion-action-sheet-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js", "common", 1],
      "./ion-alert-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js", "common", 2],
      "./ion-alert-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js", "common", 3],
      "./ion-app_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js", "common", 4],
      "./ion-app_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js", "common", 5],
      "./ion-avatar_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js", "common", 6],
      "./ion-avatar_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js", "common", 7],
      "./ion-back-button-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js", "common", 8],
      "./ion-back-button-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js", "common", 9],
      "./ion-backdrop-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js", 10],
      "./ion-backdrop-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js", 11],
      "./ion-button_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js", "common", 12],
      "./ion-button_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js", "common", 13],
      "./ion-card_5-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js", "common", 14],
      "./ion-card_5-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js", "common", 15],
      "./ion-checkbox-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js", "common", 16],
      "./ion-checkbox-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js", "common", 17],
      "./ion-chip-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js", "common", 18],
      "./ion-chip-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js", "common", 19],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 20],
      "./ion-datetime_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js", "common", 21],
      "./ion-datetime_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js", "common", 22],
      "./ion-fab_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js", "common", 23],
      "./ion-fab_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js", "common", 24],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 25],
      "./ion-infinite-scroll_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js", "common", 26],
      "./ion-infinite-scroll_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js", "common", 27],
      "./ion-input-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js", "common", 28],
      "./ion-input-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js", "common", 29],
      "./ion-item-option_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js", "common", 30],
      "./ion-item-option_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js", "common", 31],
      "./ion-item_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js", "common", 32],
      "./ion-item_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js", "common", 33],
      "./ion-loading-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js", "common", 34],
      "./ion-loading-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js", "common", 35],
      "./ion-menu_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js", "common", 36],
      "./ion-menu_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js", "common", 37],
      "./ion-modal-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js", "common", 38],
      "./ion-modal-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js", "common", 39],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 40],
      "./ion-popover-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js", "common", 41],
      "./ion-popover-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js", "common", 42],
      "./ion-progress-bar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js", "common", 43],
      "./ion-progress-bar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js", "common", 44],
      "./ion-radio_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js", "common", 45],
      "./ion-radio_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js", "common", 46],
      "./ion-range-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js", "common", 47],
      "./ion-range-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js", "common", 48],
      "./ion-refresher_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js", "common", 49],
      "./ion-refresher_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js", "common", 50],
      "./ion-reorder_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js", "common", 51],
      "./ion-reorder_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js", "common", 52],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 53],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 54],
      "./ion-searchbar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js", "common", 55],
      "./ion-searchbar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js", "common", 56],
      "./ion-segment_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js", "common", 57],
      "./ion-segment_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js", "common", 58],
      "./ion-select_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js", "common", 59],
      "./ion-select_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js", "common", 60],
      "./ion-slide_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js", 61],
      "./ion-slide_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js", 62],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 63],
      "./ion-split-pane-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js", 64],
      "./ion-split-pane-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js", 65],
      "./ion-tab-bar_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js", "common", 66],
      "./ion-tab-bar_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js", "common", 67],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 68],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 69],
      "./ion-textarea-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js", "common", 70],
      "./ion-textarea-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js", "common", 71],
      "./ion-toast-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js", "common", 72],
      "./ion-toast-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js", "common", 73],
      "./ion-toggle-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js", "common", 74],
      "./ion-toggle-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js", "common", 75],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 76]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
  /*!**************************************************!*\
    !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
    \**************************************************/

  /*! no static exports found */

  /***/
  function node_modulesMomentLocaleSyncRecursive$(module, exports, __webpack_require__) {
    var map = {
      "./af": "./node_modules/moment/locale/af.js",
      "./af.js": "./node_modules/moment/locale/af.js",
      "./ar": "./node_modules/moment/locale/ar.js",
      "./ar-dz": "./node_modules/moment/locale/ar-dz.js",
      "./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
      "./ar-kw": "./node_modules/moment/locale/ar-kw.js",
      "./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
      "./ar-ly": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ma": "./node_modules/moment/locale/ar-ma.js",
      "./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
      "./ar-sa": "./node_modules/moment/locale/ar-sa.js",
      "./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
      "./ar-tn": "./node_modules/moment/locale/ar-tn.js",
      "./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
      "./ar.js": "./node_modules/moment/locale/ar.js",
      "./az": "./node_modules/moment/locale/az.js",
      "./az.js": "./node_modules/moment/locale/az.js",
      "./be": "./node_modules/moment/locale/be.js",
      "./be.js": "./node_modules/moment/locale/be.js",
      "./bg": "./node_modules/moment/locale/bg.js",
      "./bg.js": "./node_modules/moment/locale/bg.js",
      "./bm": "./node_modules/moment/locale/bm.js",
      "./bm.js": "./node_modules/moment/locale/bm.js",
      "./bn": "./node_modules/moment/locale/bn.js",
      "./bn.js": "./node_modules/moment/locale/bn.js",
      "./bo": "./node_modules/moment/locale/bo.js",
      "./bo.js": "./node_modules/moment/locale/bo.js",
      "./br": "./node_modules/moment/locale/br.js",
      "./br.js": "./node_modules/moment/locale/br.js",
      "./bs": "./node_modules/moment/locale/bs.js",
      "./bs.js": "./node_modules/moment/locale/bs.js",
      "./ca": "./node_modules/moment/locale/ca.js",
      "./ca.js": "./node_modules/moment/locale/ca.js",
      "./cs": "./node_modules/moment/locale/cs.js",
      "./cs.js": "./node_modules/moment/locale/cs.js",
      "./cv": "./node_modules/moment/locale/cv.js",
      "./cv.js": "./node_modules/moment/locale/cv.js",
      "./cy": "./node_modules/moment/locale/cy.js",
      "./cy.js": "./node_modules/moment/locale/cy.js",
      "./da": "./node_modules/moment/locale/da.js",
      "./da.js": "./node_modules/moment/locale/da.js",
      "./de": "./node_modules/moment/locale/de.js",
      "./de-at": "./node_modules/moment/locale/de-at.js",
      "./de-at.js": "./node_modules/moment/locale/de-at.js",
      "./de-ch": "./node_modules/moment/locale/de-ch.js",
      "./de-ch.js": "./node_modules/moment/locale/de-ch.js",
      "./de.js": "./node_modules/moment/locale/de.js",
      "./dv": "./node_modules/moment/locale/dv.js",
      "./dv.js": "./node_modules/moment/locale/dv.js",
      "./el": "./node_modules/moment/locale/el.js",
      "./el.js": "./node_modules/moment/locale/el.js",
      "./en-au": "./node_modules/moment/locale/en-au.js",
      "./en-au.js": "./node_modules/moment/locale/en-au.js",
      "./en-ca": "./node_modules/moment/locale/en-ca.js",
      "./en-ca.js": "./node_modules/moment/locale/en-ca.js",
      "./en-gb": "./node_modules/moment/locale/en-gb.js",
      "./en-gb.js": "./node_modules/moment/locale/en-gb.js",
      "./en-ie": "./node_modules/moment/locale/en-ie.js",
      "./en-ie.js": "./node_modules/moment/locale/en-ie.js",
      "./en-il": "./node_modules/moment/locale/en-il.js",
      "./en-il.js": "./node_modules/moment/locale/en-il.js",
      "./en-in": "./node_modules/moment/locale/en-in.js",
      "./en-in.js": "./node_modules/moment/locale/en-in.js",
      "./en-nz": "./node_modules/moment/locale/en-nz.js",
      "./en-nz.js": "./node_modules/moment/locale/en-nz.js",
      "./en-sg": "./node_modules/moment/locale/en-sg.js",
      "./en-sg.js": "./node_modules/moment/locale/en-sg.js",
      "./eo": "./node_modules/moment/locale/eo.js",
      "./eo.js": "./node_modules/moment/locale/eo.js",
      "./es": "./node_modules/moment/locale/es.js",
      "./es-do": "./node_modules/moment/locale/es-do.js",
      "./es-do.js": "./node_modules/moment/locale/es-do.js",
      "./es-us": "./node_modules/moment/locale/es-us.js",
      "./es-us.js": "./node_modules/moment/locale/es-us.js",
      "./es.js": "./node_modules/moment/locale/es.js",
      "./et": "./node_modules/moment/locale/et.js",
      "./et.js": "./node_modules/moment/locale/et.js",
      "./eu": "./node_modules/moment/locale/eu.js",
      "./eu.js": "./node_modules/moment/locale/eu.js",
      "./fa": "./node_modules/moment/locale/fa.js",
      "./fa.js": "./node_modules/moment/locale/fa.js",
      "./fi": "./node_modules/moment/locale/fi.js",
      "./fi.js": "./node_modules/moment/locale/fi.js",
      "./fil": "./node_modules/moment/locale/fil.js",
      "./fil.js": "./node_modules/moment/locale/fil.js",
      "./fo": "./node_modules/moment/locale/fo.js",
      "./fo.js": "./node_modules/moment/locale/fo.js",
      "./fr": "./node_modules/moment/locale/fr.js",
      "./fr-ca": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ch": "./node_modules/moment/locale/fr-ch.js",
      "./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
      "./fr.js": "./node_modules/moment/locale/fr.js",
      "./fy": "./node_modules/moment/locale/fy.js",
      "./fy.js": "./node_modules/moment/locale/fy.js",
      "./ga": "./node_modules/moment/locale/ga.js",
      "./ga.js": "./node_modules/moment/locale/ga.js",
      "./gd": "./node_modules/moment/locale/gd.js",
      "./gd.js": "./node_modules/moment/locale/gd.js",
      "./gl": "./node_modules/moment/locale/gl.js",
      "./gl.js": "./node_modules/moment/locale/gl.js",
      "./gom-deva": "./node_modules/moment/locale/gom-deva.js",
      "./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
      "./gom-latn": "./node_modules/moment/locale/gom-latn.js",
      "./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
      "./gu": "./node_modules/moment/locale/gu.js",
      "./gu.js": "./node_modules/moment/locale/gu.js",
      "./he": "./node_modules/moment/locale/he.js",
      "./he.js": "./node_modules/moment/locale/he.js",
      "./hi": "./node_modules/moment/locale/hi.js",
      "./hi.js": "./node_modules/moment/locale/hi.js",
      "./hr": "./node_modules/moment/locale/hr.js",
      "./hr.js": "./node_modules/moment/locale/hr.js",
      "./hu": "./node_modules/moment/locale/hu.js",
      "./hu.js": "./node_modules/moment/locale/hu.js",
      "./hy-am": "./node_modules/moment/locale/hy-am.js",
      "./hy-am.js": "./node_modules/moment/locale/hy-am.js",
      "./id": "./node_modules/moment/locale/id.js",
      "./id.js": "./node_modules/moment/locale/id.js",
      "./is": "./node_modules/moment/locale/is.js",
      "./is.js": "./node_modules/moment/locale/is.js",
      "./it": "./node_modules/moment/locale/it.js",
      "./it-ch": "./node_modules/moment/locale/it-ch.js",
      "./it-ch.js": "./node_modules/moment/locale/it-ch.js",
      "./it.js": "./node_modules/moment/locale/it.js",
      "./ja": "./node_modules/moment/locale/ja.js",
      "./ja.js": "./node_modules/moment/locale/ja.js",
      "./jv": "./node_modules/moment/locale/jv.js",
      "./jv.js": "./node_modules/moment/locale/jv.js",
      "./ka": "./node_modules/moment/locale/ka.js",
      "./ka.js": "./node_modules/moment/locale/ka.js",
      "./kk": "./node_modules/moment/locale/kk.js",
      "./kk.js": "./node_modules/moment/locale/kk.js",
      "./km": "./node_modules/moment/locale/km.js",
      "./km.js": "./node_modules/moment/locale/km.js",
      "./kn": "./node_modules/moment/locale/kn.js",
      "./kn.js": "./node_modules/moment/locale/kn.js",
      "./ko": "./node_modules/moment/locale/ko.js",
      "./ko.js": "./node_modules/moment/locale/ko.js",
      "./ku": "./node_modules/moment/locale/ku.js",
      "./ku.js": "./node_modules/moment/locale/ku.js",
      "./ky": "./node_modules/moment/locale/ky.js",
      "./ky.js": "./node_modules/moment/locale/ky.js",
      "./lb": "./node_modules/moment/locale/lb.js",
      "./lb.js": "./node_modules/moment/locale/lb.js",
      "./lo": "./node_modules/moment/locale/lo.js",
      "./lo.js": "./node_modules/moment/locale/lo.js",
      "./lt": "./node_modules/moment/locale/lt.js",
      "./lt.js": "./node_modules/moment/locale/lt.js",
      "./lv": "./node_modules/moment/locale/lv.js",
      "./lv.js": "./node_modules/moment/locale/lv.js",
      "./me": "./node_modules/moment/locale/me.js",
      "./me.js": "./node_modules/moment/locale/me.js",
      "./mi": "./node_modules/moment/locale/mi.js",
      "./mi.js": "./node_modules/moment/locale/mi.js",
      "./mk": "./node_modules/moment/locale/mk.js",
      "./mk.js": "./node_modules/moment/locale/mk.js",
      "./ml": "./node_modules/moment/locale/ml.js",
      "./ml.js": "./node_modules/moment/locale/ml.js",
      "./mn": "./node_modules/moment/locale/mn.js",
      "./mn.js": "./node_modules/moment/locale/mn.js",
      "./mr": "./node_modules/moment/locale/mr.js",
      "./mr.js": "./node_modules/moment/locale/mr.js",
      "./ms": "./node_modules/moment/locale/ms.js",
      "./ms-my": "./node_modules/moment/locale/ms-my.js",
      "./ms-my.js": "./node_modules/moment/locale/ms-my.js",
      "./ms.js": "./node_modules/moment/locale/ms.js",
      "./mt": "./node_modules/moment/locale/mt.js",
      "./mt.js": "./node_modules/moment/locale/mt.js",
      "./my": "./node_modules/moment/locale/my.js",
      "./my.js": "./node_modules/moment/locale/my.js",
      "./nb": "./node_modules/moment/locale/nb.js",
      "./nb.js": "./node_modules/moment/locale/nb.js",
      "./ne": "./node_modules/moment/locale/ne.js",
      "./ne.js": "./node_modules/moment/locale/ne.js",
      "./nl": "./node_modules/moment/locale/nl.js",
      "./nl-be": "./node_modules/moment/locale/nl-be.js",
      "./nl-be.js": "./node_modules/moment/locale/nl-be.js",
      "./nl.js": "./node_modules/moment/locale/nl.js",
      "./nn": "./node_modules/moment/locale/nn.js",
      "./nn.js": "./node_modules/moment/locale/nn.js",
      "./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
      "./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
      "./pa-in": "./node_modules/moment/locale/pa-in.js",
      "./pa-in.js": "./node_modules/moment/locale/pa-in.js",
      "./pl": "./node_modules/moment/locale/pl.js",
      "./pl.js": "./node_modules/moment/locale/pl.js",
      "./pt": "./node_modules/moment/locale/pt.js",
      "./pt-br": "./node_modules/moment/locale/pt-br.js",
      "./pt-br.js": "./node_modules/moment/locale/pt-br.js",
      "./pt.js": "./node_modules/moment/locale/pt.js",
      "./ro": "./node_modules/moment/locale/ro.js",
      "./ro.js": "./node_modules/moment/locale/ro.js",
      "./ru": "./node_modules/moment/locale/ru.js",
      "./ru.js": "./node_modules/moment/locale/ru.js",
      "./sd": "./node_modules/moment/locale/sd.js",
      "./sd.js": "./node_modules/moment/locale/sd.js",
      "./se": "./node_modules/moment/locale/se.js",
      "./se.js": "./node_modules/moment/locale/se.js",
      "./si": "./node_modules/moment/locale/si.js",
      "./si.js": "./node_modules/moment/locale/si.js",
      "./sk": "./node_modules/moment/locale/sk.js",
      "./sk.js": "./node_modules/moment/locale/sk.js",
      "./sl": "./node_modules/moment/locale/sl.js",
      "./sl.js": "./node_modules/moment/locale/sl.js",
      "./sq": "./node_modules/moment/locale/sq.js",
      "./sq.js": "./node_modules/moment/locale/sq.js",
      "./sr": "./node_modules/moment/locale/sr.js",
      "./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr.js": "./node_modules/moment/locale/sr.js",
      "./ss": "./node_modules/moment/locale/ss.js",
      "./ss.js": "./node_modules/moment/locale/ss.js",
      "./sv": "./node_modules/moment/locale/sv.js",
      "./sv.js": "./node_modules/moment/locale/sv.js",
      "./sw": "./node_modules/moment/locale/sw.js",
      "./sw.js": "./node_modules/moment/locale/sw.js",
      "./ta": "./node_modules/moment/locale/ta.js",
      "./ta.js": "./node_modules/moment/locale/ta.js",
      "./te": "./node_modules/moment/locale/te.js",
      "./te.js": "./node_modules/moment/locale/te.js",
      "./tet": "./node_modules/moment/locale/tet.js",
      "./tet.js": "./node_modules/moment/locale/tet.js",
      "./tg": "./node_modules/moment/locale/tg.js",
      "./tg.js": "./node_modules/moment/locale/tg.js",
      "./th": "./node_modules/moment/locale/th.js",
      "./th.js": "./node_modules/moment/locale/th.js",
      "./tl-ph": "./node_modules/moment/locale/tl-ph.js",
      "./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
      "./tlh": "./node_modules/moment/locale/tlh.js",
      "./tlh.js": "./node_modules/moment/locale/tlh.js",
      "./tr": "./node_modules/moment/locale/tr.js",
      "./tr.js": "./node_modules/moment/locale/tr.js",
      "./tzl": "./node_modules/moment/locale/tzl.js",
      "./tzl.js": "./node_modules/moment/locale/tzl.js",
      "./tzm": "./node_modules/moment/locale/tzm.js",
      "./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm.js": "./node_modules/moment/locale/tzm.js",
      "./ug-cn": "./node_modules/moment/locale/ug-cn.js",
      "./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
      "./uk": "./node_modules/moment/locale/uk.js",
      "./uk.js": "./node_modules/moment/locale/uk.js",
      "./ur": "./node_modules/moment/locale/ur.js",
      "./ur.js": "./node_modules/moment/locale/ur.js",
      "./uz": "./node_modules/moment/locale/uz.js",
      "./uz-latn": "./node_modules/moment/locale/uz-latn.js",
      "./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
      "./uz.js": "./node_modules/moment/locale/uz.js",
      "./vi": "./node_modules/moment/locale/vi.js",
      "./vi.js": "./node_modules/moment/locale/vi.js",
      "./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
      "./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
      "./yo": "./node_modules/moment/locale/yo.js",
      "./yo.js": "./node_modules/moment/locale/yo.js",
      "./zh-cn": "./node_modules/moment/locale/zh-cn.js",
      "./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
      "./zh-hk": "./node_modules/moment/locale/zh-hk.js",
      "./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
      "./zh-mo": "./node_modules/moment/locale/zh-mo.js",
      "./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
      "./zh-tw": "./node_modules/moment/locale/zh-tw.js",
      "./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
    };

    function webpackContext(req) {
      var id = webpackContextResolve(req);
      return __webpack_require__(id);
    }

    function webpackContextResolve(req) {
      if (!__webpack_require__.o(map, req)) {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      }

      return map[req];
    }

    webpackContext.keys = function webpackContextKeys() {
      return Object.keys(map);
    };

    webpackContext.resolve = webpackContextResolve;
    module.exports = webpackContext;
    webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\r\n    <p-toast class=\"toast-item\"></p-toast>\r\n\r\n    <ion-split-pane id=\"app-split-pane\" contentId=\"main-content\" *ngIf=\"isAuthenticated\">\r\n        <ion-menu id=\"nav-menu\" contentId=\"main-content\" type=\"overlay\">\r\n            <ion-header>\r\n                <ion-toolbar>\r\n                  <!--App Titale-->\r\n                  <ion-title slot=\"start\">\r\n                        MyBaseApp\r\n                    </ion-title>\r\n                  <!--Language selector-->\r\n                    <!-- <ion-select class=\"popoverMinimal\" [(ngModel)]=\"currentLang\" slot=\"end\" interface=\"popover\"\r\n                        [interfaceOptions]=\"langPopoverOptions\" (ionChange)=\"onChangeLocalization($event)\">\r\n                        <ion-select-option *ngFor=\"let lg of languageOpts;\" [value]=\"lg.cultureName\">\r\n                            {{lg.displayName}}\r\n                        </ion-select-option>\r\n                    </ion-select> -->\r\n                \r\n                </ion-toolbar>\r\n            </ion-header>\r\n\r\n            <ion-content>\r\n                <ion-list id=\"nav-menu-list\">\r\n                    <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let mnu of navList;let i = index\">\r\n                        <ion-item (click)=\"selectedIndex = i\" detail=\"false\" lines=\"none\" [routerLink]=\"mnu.route\"\r\n                            [class.selected]=\"selectedIndex == i\">\r\n                            <ion-icon [name]=\"mnu.icon\" slot=\"start\"></ion-icon>\r\n                            <ion-label>{{mnu.title}}</ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n\r\n                    <ion-menu-toggle auto-hide=\"false\">\r\n                        <ion-item lines=\"none\" (click)=\"onLogOut()\" button>\r\n                            <ion-icon name=\"exit\" slot=\"start\"></ion-icon>\r\n                            <ion-label>Logout</ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n                </ion-list>\r\n            </ion-content>\r\n        </ion-menu>\r\n        <ion-router-outlet id=\"main-content\">\r\n\r\n        </ion-router-outlet>\r\n    </ion-split-pane>\r\n\r\n    <ion-router-outlet main *ngIf=\"!isAuthenticated\"></ion-router-outlet>\r\n</ion-app>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/location-picker.presenter.html":
  /*!****************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/location-picker.presenter.html ***!
    \****************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppZNestCorePresentersLocationPickerLocationPickerPresenterHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"picker\">\n  <ion-spinner color=\"primary\" *ngIf=\"isLoading\"></ion-spinner>\n  <ion-button\n  color=\"primary\"\n  (click)=\"onPickLocation()\"\n  *ngIf=\"!selectedLocationImage && !isLoading\"\n>\n  <ion-icon name=\"map\" slot=\"start\"></ion-icon>\n  <ion-label>Select Location</ion-label>\n</ion-button>\n\n  <ion-img\n    role=\"button\"\n    class=\"location-image\"\n    (click)=\"onPickLocation()\"\n    [src]=\"selectedLocationImage\"\n    *ngIf=\"selectedLocationImage && !isLoading\"\n  ></ion-img>\n \n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.html":
  /*!********************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.html ***!
    \********************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppZNestCorePresentersLocationPickerMapModalMapModalComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{ title }}</ion-title>\n    <ion-buttons slot=\"primary\">\n      <ion-button (click)=\"onCancel()\">{{ closeButtonText }}</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"map\" #map></div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/data-grid/tmpl-grid.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/data-grid/tmpl-grid.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppZNestCoreTemplatesDataGridTmplGridHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p-table #dt [value]=\"dataTable.value\" [columns]=\"dataTable.columns\" [rows]=\"dataTable.rows\"\r\n  [paginator]=\"dataTable.paginator\" [pageLinks]=\"dataTable.pageLinks\"\r\n  [rowsPerPageOptions]=\"dataTable.rowsPerPageOptions\" [selectionMode]=\"dataTable.selectionMode\"\r\n  [resizableColumns]=\"dataTable.resizableColumns\" [(selection)]=\"selectedRowData\" (onRowSelect)=\"onRowSelect($event)\"\r\n  (onRowUnselect)=\"onRowUnselect($event)\" dataKey=\"name\" sortMode=\"multiple\" [metaKeySelection]=\"false\">\r\n\r\n  <ng-template pTemplate=\"caption\" style=\"padding: 0px;\">\r\n    <table style=\"padding: 0px;\">\r\n      <thead>\r\n        <tr>\r\n          <th align=\"center\" width=\"90%\">\r\n            <span>{{dataTable.tableCaption}}</span>\r\n          </th>\r\n          <th align=\"right\" width=\"10%\">\r\n            <ion-button style=\"margin:0px\" (click)=\"showSearchRow=!showSearchRow\" color=\"medium\" size=\"small\"\r\n              title=\"Filter table data\"\r\n              class=\"action-buttons\" \r\n              fill=\"clear\" shape=\"round\">\r\n              <ion-icon slot=\"icon-only\" name=\"search-outline\"></ion-icon>\r\n            </ion-button>\r\n          </th>\r\n        </tr>\r\n      </thead>\r\n    </table>\r\n  </ng-template>\r\n  <ng-template pTemplate=\"header\" let-columns>\r\n    <tr>\r\n      <th *ngFor=\"let col of columns\" [pSortableColumn]=\"col.field\" [ngClass]=\"col.styleClass\">\r\n        {{col.header}}\r\n        <p-sortIcon class=\"dataTableSortIcon\" [field]=\"col.field\"></p-sortIcon>\r\n      </th>\r\n    </tr>\r\n    <tr id=\"dataTableSearchRow\" *ngIf=\"showSearchRow\">\r\n      <th *ngFor=\"let col of columns\" [ngSwitch]=\"col.field\" [ngClass]=\"col.styleClass\">\r\n        <input pInputText type=\"text\" (input)=\"dt.filter($event.target.value,col.field,col.filterMatchMode)\" />\r\n      </th>\r\n    </tr>\r\n  </ng-template>\r\n  <ng-template pTemplate=\"body\" let-rowData let-columns=\"columns\">\r\n    <tr [pSelectableRow]=\"rowData\">\r\n\r\n      <td *ngFor=\"let col of columns\" [ngClass]=\"col.styleClass\">\r\n       <span *ngIf=\"!col.isViewDetailLink\"> {{rowData[col.field]}}</span>\r\n        <a *ngIf=\"col.isViewDetailLink\" (click)=\"onViewDetail(col.field,rowData)\">\r\n          {{rowData[col.field]}}\r\n        </a>\r\n      </td>\r\n\r\n    </tr>\r\n  </ng-template>\r\n</p-table>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/form/tmpl-form.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/form/tmpl-form.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppZNestCoreTemplatesFormTmplFormHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<form novalidate [formGroup]=\"_localDataForm\">\r\n  <div *ngFor=\"let field of _localDataModel.fields| nestFilterPipe:filterFormField\">\r\n    <ion-item *ngIf=\"field.controlType==nestFormCtrlType.INPUT\">\r\n      <ion-label position=\"floating\">{{field.label}}</ion-label>\r\n      <ion-input type=\"{{field.type}}\" clearInput=\"true\" id=\"{{field.name}}\" formControlName=\"{{field.name}}\">\r\n      </ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item *ngIf=\"field.controlType==nestFormCtrlType.CHECKBOX\">\r\n      <ion-label position=\"fixed\">{{field.label}}</ion-label>\r\n      <ion-checkbox id=\"{{field.name}}\" formControlName=\"{{field.name}}\"></ion-checkbox>\r\n    </ion-item>\r\n\r\n    <ion-item *ngIf=\"field.controlType==nestFormCtrlType.TEXTAREA\">\r\n      <ion-label position=\"floating\">{{field.label}}</ion-label>\r\n      <ion-textarea id=\"{{field.name}}\" clearInput=\"true\" formControlName=\"{{field.name}}\"></ion-textarea>\r\n    </ion-item>\r\n\r\n    <span class=\"nest-form-validation-help-block\" *ngIf=\"validateForm(field.name)\">\r\n      {{_errMessage}}\r\n    </span>\r\n  </div>\r\n\r\n  <div>\r\n    <ion-button color=\"success\" (click)=\"formSubmit()\" [disabled]=\"!_localDataForm.valid\">\r\n      {{_submitFormTitle}}\r\n    </ion-button>\r\n  </div>\r\n</form>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.html":
  /*!********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.html ***!
    \********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppZNestCoreTemplatesViewsDetailViewTmplDetailViewHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"content-header  content-non-mobile\">\r\n  <ion-grid class=\"ion-no-padding\">\r\n    <ion-row>\r\n      <ion-col size=\"1\">\r\n        <ion-button size=\"small\"  (click)=\"onNavigateBack()\" color=\"primary\" class=\"nav-buttons\" \r\n        expand=\"block\" fill=\"outline\" shape=\"round\">\r\n          <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n      \r\n      <ion-col offset=\"8\" size=\"2\"  >\r\n       <ion-button *ngFor=\"let btn of buttonActions\" \r\n       size=\"small\" (click)=\"btnActionSelected(btn)\" color=\"primary\" class=\"action-buttons\" \r\n       fill=\"clear\" shape=\"round\" [title]=\"btn.label\">\r\n        <ion-icon slot=\"icon-only\" [name]=\"btn.icon\" ></ion-icon>\r\n       </ion-button>\r\n      </ion-col>\r\n      \r\n      <ion-col size=\"1\" >\r\n        <ion-button size=\"small\"  color=\"primary\" class=\"action-buttons\" \r\n        expand=\"block\" fill=\"outline\" shape=\"round\" (click)=\"onToggleContextMenu(ctx_menu,$event)\">\r\n        Menu\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</div>\r\n<p-contextMenu [global]=\"false\" #ctx_menu [model]=\"menuActions\" appendTo=\"body\" styleClass=\"primengCtxMenu\"></p-contextMenu>\r\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : new P(function (resolve) {
            resolve(result.value);
          }).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var m = typeof Symbol === "function" && o[Symbol.iterator],
          i = 0;
      if (m) return m.call(o);
      return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result.default = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        default: mod
      };
    }
    /***/

  },

  /***/
  "./src/app/app-routes.ts":
  /*!*******************************!*\
    !*** ./src/app/app-routes.ts ***!
    \*******************************/

  /*! exports provided: appRoutes */

  /***/
  function srcAppAppRoutesTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "appRoutes", function () {
      return appRoutes;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./auth/auth.guard */
    "./src/app/auth/auth.guard.ts");

    var appRoutes = [{
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full'
    }, {
      path: 'auth',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | auth-auth-module */
        "auth-auth-module").then(__webpack_require__.bind(null,
        /*! ./auth/auth.module */
        "./src/app/auth/auth.module.ts")).then(function (m) {
          return m.AuthPageModule;
        });
      }
    }, {
      path: 'dashboard',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | dashboard-dashboard-module */
        "dashboard-dashboard-module").then(__webpack_require__.bind(null,
        /*! ./dashboard/dashboard.module */
        "./src/app/dashboard/dashboard.module.ts")).then(function (m) {
          return m.DashboardPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }, {
      path: 'delivery',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | delivery-delivery-module */
        "delivery-delivery-module").then(__webpack_require__.bind(null,
        /*! ./delivery/delivery.module */
        "./src/app/delivery/delivery.module.ts")).then(function (m) {
          return m.DeliveryPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }, // {
    //     path: 'customers',
    //     loadChildren: () => import('./customers/customers.module').then(m => m.CustomersPageModule),
    //     canLoad: [AuthGuard]
    // },
    {
      path: 'reports',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | reports-reports-module */
        "reports-reports-module").then(__webpack_require__.bind(null,
        /*! ./reports/reports.module */
        "./src/app/reports/reports.module.ts")).then(function (m) {
          return m.ReportsPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }, {
      path: 'settings',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | settings-settings-module */
        "settings-settings-module").then(__webpack_require__.bind(null,
        /*! ./settings/settings.module */
        "./src/app/settings/settings.module.ts")).then(function (m) {
          return m.SettingsPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }, {
      path: 'about',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | about-about-module */
        "about-about-module").then(__webpack_require__.bind(null,
        /*! ./about/about.module */
        "./src/app/about/about.module.ts")).then(function (m) {
          return m.AboutPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }, {
      path: 'order',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | order-order-module */
        "order-order-module").then(__webpack_require__.bind(null,
        /*! ./order/order.module */
        "./src/app/order/order.module.ts")).then(function (m) {
          return m.OrderPageModule;
        });
      },
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"]]
    }];
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _app_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app-routes */
    "./src/app/app-routes.ts");

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(_app_routes__WEBPACK_IMPORTED_MODULE_3__["appRoutes"])],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
      schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["NO_ERRORS_SCHEMA"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "#app-split-pane {\n  --side-min-width:100px;\n  --side-max-width:200px;\n}\n\n#nav-menu-list {\n  background-color: #fff;\n}\n\n#nav-menu-list ion-item {\n  height: 34px !important;\n}\n\n#nav-menu-list ion-icon {\n  color: var(--ion-color-primary);\n  margin: 0px 10px 0px 0px !important;\n  font-size: 20px !important;\n}\n\n#nav-menu-list ion-label {\n  font-size: 14px;\n  min-height: 10px;\n  font-weight: 500;\n}\n\n#nav-menu-list ion-item.selected {\n  --background: rgba(var(--ion-color-secondary-rgb), 0.14);\n}\n\n#nav-menu-list ion-item.selected ion-icon {\n  color: var(--ion-color-secondary);\n}\n\n#nav-menu-list ion-item.selected ion-label {\n  font-weight: 800;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvRjpcXFByb2plY3RzXFxNeSBQcm9qZWN0c1xcTW9iaWxlQXBwXFxTd2lmdFxcc3dpZnQtY2xpZW50L3NyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFRTtFQUNFLHNCQUFBO0FDQ0o7O0FEQ0U7RUFDRix1QkFBQTtBQ0VBOztBRENFO0VBQ0UsK0JBQUE7RUFDQSxtQ0FBQTtFQUNBLDBCQUFBO0FDRUo7O0FEQ0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0VKOztBRENFO0VBQ0Usd0RBQUE7QUNFSjs7QURDRTtFQUNFLGlDQUFBO0FDRUo7O0FEQUU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUNHSiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNhcHAtc3BsaXQtcGFuZXtcclxuICAgIC0tc2lkZS1taW4td2lkdGg6MTAwcHg7XHJcbiAgICAtLXNpZGUtbWF4LXdpZHRoOjIwMHB4O1xyXG4gIFxyXG4gIH1cclxuICAjbmF2LW1lbnUtbGlzdCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7XHJcbiAgfVxyXG4gICNuYXYtbWVudS1saXN0IGlvbi1pdGVte1xyXG5oZWlnaHQ6MzRweCAhaW1wb3J0YW50IDtcclxuICB9XHJcblxyXG4gICNuYXYtbWVudS1saXN0IGlvbi1pY29uIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBtYXJnaW46IDBweCAxMHB4IDBweCAwcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMjBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAjbmF2LW1lbnUtbGlzdCBpb24tbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgbWluLWhlaWdodDogMTBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgfVxyXG4gIFxyXG4gICNuYXYtbWVudS1saXN0IGlvbi1pdGVtLnNlbGVjdGVkIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5LXJnYiksIDAuMTQpO1xyXG4gIH1cclxuICBcclxuICAjbmF2LW1lbnUtbGlzdCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbiAgfVxyXG4gICNuYXYtbWVudS1saXN0IGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1sYWJlbCB7XHJcbiAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxuXHJcblxyXG4gICIsIiNhcHAtc3BsaXQtcGFuZSB7XG4gIC0tc2lkZS1taW4td2lkdGg6MTAwcHg7XG4gIC0tc2lkZS1tYXgtd2lkdGg6MjAwcHg7XG59XG5cbiNuYXYtbWVudS1saXN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuI25hdi1tZW51LWxpc3QgaW9uLWl0ZW0ge1xuICBoZWlnaHQ6IDM0cHggIWltcG9ydGFudDtcbn1cblxuI25hdi1tZW51LWxpc3QgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBtYXJnaW46IDBweCAxMHB4IDBweCAwcHggIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbiNuYXYtbWVudS1saXN0IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbWluLWhlaWdodDogMTBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuI25hdi1tZW51LWxpc3QgaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeS1yZ2IpLCAwLjE0KTtcbn1cblxuI25hdi1tZW51LWxpc3QgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG59XG5cbiNuYXYtbWVudS1saXN0IGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _app_main_shared__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @app_main/shared */
    "./src/app/shared/index.ts");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");

    var AppComponent =
    /*#__PURE__*/
    function () {
      function AppComponent(platform, splashScreen, statusBar, authSvc, mainSvc) {
        _classCallCheck(this, AppComponent);

        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.authSvc = authSvc;
        this.mainSvc = mainSvc;
        this.isAuthenticated = false;
        this.prevAuthState = false;
        this.initializeApp();
      }

      _createClass(AppComponent, [{
        key: "initializeApp",
        value: function initializeApp() {
          this.platform.ready().then(function () {
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Capacitor"].isPluginAvailable('SplashScreen')) _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].SplashScreen.hide();
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.initStarterData(); //    this.initLanguageOpts();
        }
      }, {
        key: "initStarterData",
        value: function initStarterData() {
          var _this = this;

          this.authSvc.authenticationChanged$.subscribe(function (isAuth) {
            if (isAuth) {
              _this.isAuthenticated = true;
              _this.navList = _this.mainSvc.getNavigationList();
            } else {
              _this.navList = [];
              _this.isAuthenticated = false;
            }
          });
        }
      }, {
        key: "initLanguageOpts",
        value: function initLanguageOpts() {
          this.langPopoverOptions = {
            header: "Language"
          };
          this.languageOpts = [];
          this.currentLang = "";
        }
      }, {
        key: "onChangeLocalization",
        value: function onChangeLocalization(event) {
          console.log("selected culture: " + event.detail.value); // this.store.dispatch(new SetLanguage(event.detail.value)).subscribe(()=>{
          // window.location.reload();
          // });
        }
      }, {
        key: "onLogOut",
        value: function onLogOut() {
          this.authSvc.logout();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {}
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
      }, {
        type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"]
      }, {
        type: _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["MainAppService"]
      }];
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"], _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"], _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["MainAppService"]])], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ngxs_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ngxs/store */
    "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
    /* harmony import */


    var _envt_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @envt/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_main_shared__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @app_main/shared */
    "./src/app/shared/index.ts");
    /* harmony import */


    var _nest_nest_shared_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @nest/nest-shared.module */
    "./src/app/zNest/nest-shared.module.ts");
    /* harmony import */


    var _angular_fire__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @angular/fire */
    "./node_modules/@angular/fire/fesm2015/angular-fire.js");
    /* harmony import */


    var _angular_fire_database__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @angular/fire/database */
    "./node_modules/@angular/fire/fesm2015/angular-fire-database.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js"); //import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
    //const LOGGERS = [NgxsLoggerPluginModule.forRoot({ disabled: true })];


    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_ngxs_store__WEBPACK_IMPORTED_MODULE_2__["NgxsModule"].forRoot([_app_main_shared__WEBPACK_IMPORTED_MODULE_13__["ZooState"]], {
        selectorOptions: {
          suppressErrors: false // `true` by default

        }
      }), _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["BrowserModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_12__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"], _nest_nest_shared_module__WEBPACK_IMPORTED_MODULE_14__["NestSharedModule"], // ...(environment.production ? [] : LOGGERS),
      _angular_fire__WEBPACK_IMPORTED_MODULE_15__["AngularFireModule"].initializeApp(_envt_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].firebaseConfig), _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_17__["AngularFirestoreModule"], _angular_fire_database__WEBPACK_IMPORTED_MODULE_16__["AngularFireDatabaseModule"]],
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"]],
      providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_9__["SplashScreen"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicRouteStrategy"]
      }],
      schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["NO_ERRORS_SCHEMA"]],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/auth/auth.guard.ts":
  /*!************************************!*\
    !*** ./src/app/auth/auth.guard.ts ***!
    \************************************/

  /*! exports provided: AuthGuard */

  /***/
  function srcAppAuthAuthGuardTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthGuard", function () {
      return AuthGuard;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var AuthGuard =
    /*#__PURE__*/
    function () {
      function AuthGuard(authSvc) {
        _classCallCheck(this, AuthGuard);

        this.authSvc = authSvc;
      }

      _createClass(AuthGuard, [{
        key: "canActivate",
        value: function canActivate(next, state) {
          return this.checkDefaultGuard();
        }
      }, {
        key: "canActivateChild",
        value: function canActivateChild(next, state) {
          return true;
        }
      }, {
        key: "canLoad",
        value: function canLoad(route, segments) {
          return this.checkDefaultGuard();
        }
      }, {
        key: "checkDefaultGuard",
        value: function checkDefaultGuard() {
          var _this2 = this;

          return this.authSvc.userIsAuthenticated.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (isAuth) {
            if (!isAuth) return _this2.authSvc.autoLogin();else return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(isAuth);
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (isAuth) {
            if (!isAuth) _this2.authSvc.goToLoginPage();
          }));
        }
      }]);

      return AuthGuard;
    }();

    AuthGuard.ctorParameters = function () {
      return [{
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])], AuthGuard);
    /***/
  },

  /***/
  "./src/app/auth/auth.service.ts":
  /*!**************************************!*\
    !*** ./src/app/auth/auth.service.ts ***!
    \**************************************/

  /*! exports provided: AuthService */

  /***/
  function srcAppAuthAuthServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthService", function () {
      return AuthService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _envt_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @envt/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_main_shared__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @app_main/shared */
    "./src/app/shared/index.ts");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AuthService =
    /*#__PURE__*/
    function () {
      function AuthService(_http, router, mainAppSvc) {
        _classCallCheck(this, AuthService);

        this._http = _http;
        this.router = router;
        this.mainAppSvc = mainAppSvc;
        this.offlineMode = true;
        this.authenticationChanged$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
        this.offlineMode = this.mainAppSvc.offlineMode;
      }

      _createClass(AuthService, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.autoLogoutTimeOut) {
            clearTimeout(this.autoLogoutTimeOut);
          }
        }
      }, {
        key: "autoLogin",
        value: function autoLogin() {
          var _this3 = this;

          return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.get({
            key: 'AuthData'
          })).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (storedData) {
            if (!storedData || !storedData.value) {
              return false;
            }

            var parsedData = JSON.parse(storedData.value);
            var user = new _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["User"](parsedData.id, parsedData.email, parsedData.token, new Date(parsedData.tokenExpiry));

            if (user.tokenDuration <= 0) {
              return false;
            } else {
              _this3.authenticationChanged$.next(user);

              _this3.autoLogout(user.tokenDuration);
            }

            return true;
          }));
        }
      }, {
        key: "goToLoginPage",
        value: function goToLoginPage() {
          this.router.navigateByUrl('/auth');
        }
      }, {
        key: "goToHomePage",
        value: function goToHomePage() {
          this.router.navigateByUrl('/dashboard');
        }
      }, {
        key: "login",
        value: function login(email, psw) {
          var _this4 = this;

          return this._http.post("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=".concat(_envt_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].firebaseConfig.apiKey), {
            email: email,
            password: psw,
            returnSecureToken: true
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(function (uData) {
            _this4.setUserData(uData);
          }));
        }
      }, {
        key: "signUp",
        value: function signUp(email, psw) {
          var _this5 = this;

          return this._http.post("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=".concat(_envt_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].firebaseConfig.apiKey), {
            email: email,
            password: psw,
            returnSecureToken: true
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(function (uData) {
            _this5.setUserData(uData);
          }));
        }
      }, {
        key: "setUserData",
        value: function setUserData(uData) {
          var expTime = new Date(new Date().getTime() + +uData.expiresIn * 1000);
          var user = new _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["User"](uData.localId, uData.email, uData.idToken, expTime);
          this.authenticationChanged$.next(user);
          var data = JSON.stringify({
            id: user.id,
            email: user.email,
            token: user.token,
            tokenExpiry: expTime.toISOString()
          });

          _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.set({
            key: 'AuthData',
            value: data
          });

          this.autoLogout(user.tokenDuration);
        }
      }, {
        key: "logout",
        value: function logout() {
          if (this.autoLogoutTimeOut) {
            clearTimeout(this.autoLogoutTimeOut);
          }

          this.authenticationChanged$.next(null);

          _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"].Storage.remove({
            key: 'AuthData'
          });

          this.goToLoginPage();
        }
      }, {
        key: "autoLogout",
        value: function autoLogout(duration) {
          var _this6 = this;

          if (this.autoLogoutTimeOut) {
            clearTimeout(this.autoLogoutTimeOut);
          }

          this.autoLogoutTimeOut = setTimeout(function () {
            _this6.logout();
          }, duration);
        }
      }, {
        key: "offlineLogin",
        value: function offlineLogin() {
          var _this7 = this;

          this.autoLogin().subscribe(function (isAuth) {
            if (isAuth) _this7.goToHomePage();else {
              var dt = {
                localId: '123',
                email: 'tests@test.com',
                idToken: Math.random.toString(),
                expiresIn: new Date(2020, 7, 1).valueOf().toString(),
                refreshToken: 'true'
              };

              _this7.setUserData(dt);

              _this7.goToHomePage();
            }
          });
        }
      }, {
        key: "userIsAuthenticated",
        get: function get() {
          return this.authenticationChanged$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (u) {
            if (u) return !!u.token;else return false;
          }));
        }
      }, {
        key: "userId",
        get: function get() {
          return this.authenticationChanged$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (u) {
            if (u) return u.id;else return null;
          }));
        }
      }]);

      return AuthService;
    }();

    AuthService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]
      }, {
        type: _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["MainAppService"]
      }];
    };

    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"], _app_main_shared__WEBPACK_IMPORTED_MODULE_6__["MainAppService"]])], AuthService);
    /***/
  },

  /***/
  "./src/app/shared/index.ts":
  /*!*********************************!*\
    !*** ./src/app/shared/index.ts ***!
    \*********************************/

  /*! exports provided: User, CustomerDto, CreateUpdateCustomerDto, MainAppService, ZooDuty, ZOO_STATE_TOKEN, ZooState */

  /***/
  function srcAppSharedIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _models_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./models/index */
    "./src/app/shared/models/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "User", function () {
      return _models_index__WEBPACK_IMPORTED_MODULE_1__["User"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CustomerDto", function () {
      return _models_index__WEBPACK_IMPORTED_MODULE_1__["CustomerDto"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CreateUpdateCustomerDto", function () {
      return _models_index__WEBPACK_IMPORTED_MODULE_1__["CreateUpdateCustomerDto"];
    });
    /* harmony import */


    var _services_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./services/index */
    "./src/app/shared/services/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "MainAppService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_2__["MainAppService"];
    });
    /* harmony import */


    var _states_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./states/index */
    "./src/app/shared/states/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooDuty", function () {
      return _states_index__WEBPACK_IMPORTED_MODULE_3__["ZooDuty"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZOO_STATE_TOKEN", function () {
      return _states_index__WEBPACK_IMPORTED_MODULE_3__["ZOO_STATE_TOKEN"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooState", function () {
      return _states_index__WEBPACK_IMPORTED_MODULE_3__["ZooState"];
    });
    /* shared models */

    /* shared services */

    /* shared states */

    /***/

  },

  /***/
  "./src/app/shared/models/create-update-customer-dto.model.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/shared/models/create-update-customer-dto.model.ts ***!
    \*******************************************************************/

  /*! exports provided: CreateUpdateCustomerDto */

  /***/
  function srcAppSharedModelsCreateUpdateCustomerDtoModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CreateUpdateCustomerDto", function () {
      return CreateUpdateCustomerDto;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var CreateUpdateCustomerDto = function CreateUpdateCustomerDto() {
      var initialValues = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, CreateUpdateCustomerDto);

      if (initialValues) {
        for (var key in initialValues) {
          if (initialValues.hasOwnProperty(key)) {
            this[key] = initialValues[key];
          }
        }
      }
    };
    /***/

  },

  /***/
  "./src/app/shared/models/customer-dto.model.ts":
  /*!*****************************************************!*\
    !*** ./src/app/shared/models/customer-dto.model.ts ***!
    \*****************************************************/

  /*! exports provided: CustomerDto */

  /***/
  function srcAppSharedModelsCustomerDtoModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomerDto", function () {
      return CustomerDto;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var CustomerDto = function CustomerDto() {
      _classCallCheck(this, CustomerDto);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/index.ts":
  /*!****************************************!*\
    !*** ./src/app/shared/models/index.ts ***!
    \****************************************/

  /*! exports provided: User, CustomerDto, CreateUpdateCustomerDto */

  /***/
  function srcAppSharedModelsIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _user_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./user.model */
    "./src/app/shared/models/user.model.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "User", function () {
      return _user_model__WEBPACK_IMPORTED_MODULE_1__["User"];
    });
    /* harmony import */


    var _customer_dto_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./customer-dto.model */
    "./src/app/shared/models/customer-dto.model.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CustomerDto", function () {
      return _customer_dto_model__WEBPACK_IMPORTED_MODULE_2__["CustomerDto"];
    });
    /* harmony import */


    var _create_update_customer_dto_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./create-update-customer-dto.model */
    "./src/app/shared/models/create-update-customer-dto.model.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CreateUpdateCustomerDto", function () {
      return _create_update_customer_dto_model__WEBPACK_IMPORTED_MODULE_3__["CreateUpdateCustomerDto"];
    });
    /***/

  },

  /***/
  "./src/app/shared/models/user.model.ts":
  /*!*********************************************!*\
    !*** ./src/app/shared/models/user.model.ts ***!
    \*********************************************/

  /*! exports provided: User */

  /***/
  function srcAppSharedModelsUserModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "User", function () {
      return User;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var User =
    /*#__PURE__*/
    function () {
      function User(id, email, _token, _tokenExpiryDate) {
        _classCallCheck(this, User);

        this.id = id;
        this.email = email;
        this._token = _token;
        this._tokenExpiryDate = _tokenExpiryDate;
      }

      _createClass(User, [{
        key: "token",
        get: function get() {
          if (!this._tokenExpiryDate || this._tokenExpiryDate <= new Date()) return null;else return this._token;
        }
      }, {
        key: "tokenDuration",
        get: function get() {
          if (!this.token) return 0;
          return this._tokenExpiryDate.getTime() - new Date().getTime();
        }
      }]);

      return User;
    }();
    /***/

  },

  /***/
  "./src/app/shared/services/index.ts":
  /*!******************************************!*\
    !*** ./src/app/shared/services/index.ts ***!
    \******************************************/

  /*! exports provided: MainAppService */

  /***/
  function srcAppSharedServicesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _main_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./main-app.service */
    "./src/app/shared/services/main-app.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "MainAppService", function () {
      return _main_app_service__WEBPACK_IMPORTED_MODULE_1__["MainAppService"];
    });
    /***/

  },

  /***/
  "./src/app/shared/services/main-app.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/shared/services/main-app.service.ts ***!
    \*****************************************************/

  /*! exports provided: MainAppService */

  /***/
  function srcAppSharedServicesMainAppServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MainAppService", function () {
      return MainAppService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");

    var MainAppService =
    /*#__PURE__*/
    function () {
      function MainAppService(_toastCtrl, _http) {
        _classCallCheck(this, MainAppService);

        this._toastCtrl = _toastCtrl;
        this._http = _http;
        this.offlineMode = true;
        this.fillNavList();
        this.offlineChecker();
      }

      _createClass(MainAppService, [{
        key: "offlineChecker",
        value: function offlineChecker() {
          var _this8 = this;

          this._http.get('https://www.google.com').subscribe(function (result) {
            _this8.offlineMode = false;
          }, function (err) {
            _this8.offlineMode = true;
            console.log(JSON.stringify(err));
          });
        }
      }, {
        key: "getNavigationList",
        value: function getNavigationList() {
          return this.navList;
        }
      }, {
        key: "fillNavList",
        value: function fillNavList() {
          this.navList = [{
            id: "dashboard",
            title: "Dashboard",
            route: "/dashboard",
            icon: "speedometer",
            order: 1,
            isDefaultPath: true
          }, {
            id: "order",
            title: "Orders",
            route: "/order",
            icon: "list",
            order: 2,
            isDefaultPath: false
          }, {
            id: "delivery",
            title: "Delivery",
            route: "/delivery",
            icon: "list",
            order: 2,
            isDefaultPath: false
          }, {
            id: "customers",
            title: "Customers",
            route: "/customers",
            icon: "people",
            order: 5,
            isDefaultPath: false
          }, {
            id: "settings",
            title: "Settings",
            route: "/settings",
            icon: "cog",
            order: 8,
            isDefaultPath: false
          }, {
            id: "reports",
            title: "Reports",
            route: "/reports",
            icon: "document",
            order: 8,
            isDefaultPath: false
          }, {
            id: "about",
            title: "About",
            route: "/about",
            icon: "information",
            order: 8,
            isDefaultPath: false
          }];
        }
      }]);

      return MainAppService;
    }();

    MainAppService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }];
    };

    MainAppService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])], MainAppService);
    /***/
  },

  /***/
  "./src/app/shared/states/index.ts":
  /*!****************************************!*\
    !*** ./src/app/shared/states/index.ts ***!
    \****************************************/

  /*! exports provided: ZooDuty, ZOO_STATE_TOKEN, ZooState */

  /***/
  function srcAppSharedStatesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _zoo_state_zoo_state_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./zoo-state/zoo-state.index */
    "./src/app/shared/states/zoo-state/zoo-state.index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooDuty", function () {
      return _zoo_state_zoo_state_index__WEBPACK_IMPORTED_MODULE_1__["ZooDuty"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZOO_STATE_TOKEN", function () {
      return _zoo_state_zoo_state_index__WEBPACK_IMPORTED_MODULE_1__["ZOO_STATE_TOKEN"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooState", function () {
      return _zoo_state_zoo_state_index__WEBPACK_IMPORTED_MODULE_1__["ZooState"];
    });
    /***/

  },

  /***/
  "./src/app/shared/states/zoo-state/actions.ts":
  /*!****************************************************!*\
    !*** ./src/app/shared/states/zoo-state/actions.ts ***!
    \****************************************************/

  /*! exports provided: ZooDuty */

  /***/
  function srcAppSharedStatesZooStateActionsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ZooDuty", function () {
      return ZooDuty;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var ZooDuty;

    (function (ZooDuty) {
      var FeedAnimals = function FeedAnimals(payload) {
        _classCallCheck(this, FeedAnimals);

        this.payload = payload;
      };

      FeedAnimals.type = '[Zoo] Feed Animals';
      ZooDuty.FeedAnimals = FeedAnimals;

      var CountAnimals = function CountAnimals() {
        _classCallCheck(this, CountAnimals);
      };

      CountAnimals.type = '[Zoo] Count Animals';
      ZooDuty.CountAnimals = CountAnimals;

      var KillAnimals = function KillAnimals(id) {
        _classCallCheck(this, KillAnimals);

        this.id = id;
      };

      KillAnimals.type = '[Zoo] Kill Animals';
      ZooDuty.KillAnimals = KillAnimals;
    })(ZooDuty || (ZooDuty = {}));
    /***/

  },

  /***/
  "./src/app/shared/states/zoo-state/state.ts":
  /*!**************************************************!*\
    !*** ./src/app/shared/states/zoo-state/state.ts ***!
    \**************************************************/

  /*! exports provided: ZOO_STATE_TOKEN, ZooState */

  /***/
  function srcAppSharedStatesZooStateStateTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ZOO_STATE_TOKEN", function () {
      return ZOO_STATE_TOKEN;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ZooState", function () {
      return ZooState;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ngxs_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ngxs/store */
    "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
    /* harmony import */


    var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./actions */
    "./src/app/shared/states/zoo-state/actions.ts");

    var ZOO_STATE_TOKEN = new _ngxs_store__WEBPACK_IMPORTED_MODULE_2__["StateToken"]('zoo');

    var ZooState =
    /*#__PURE__*/
    function () {
      function ZooState() {
        _classCallCheck(this, ZooState);
      }

      _createClass(ZooState, [{
        key: "feedAnimals",
        value: function feedAnimals(ctx, action) {
          var state = ctx.getState();
          ctx.patchState({
            name: action.payload.name,
            hasEaten: action.payload.hayAmount > 0 ? true : false
          });
        }
      }], [{
        key: "hasEaten",
        value: function hasEaten(state) {
          return state.hasEaten ? state : null;
        }
      }]);

      return ZooState;
    }();

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_2__["Action"])(_actions__WEBPACK_IMPORTED_MODULE_3__["ZooDuty"].FeedAnimals), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _actions__WEBPACK_IMPORTED_MODULE_3__["ZooDuty"].FeedAnimals]), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)], ZooState.prototype, "feedAnimals", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_2__["Selector"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", Object)], ZooState, "hasEaten", null);
    ZooState = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_2__["State"])({
      name: ZOO_STATE_TOKEN,
      defaults: null // if you specify the wrong state type, will be a compilation error

    }), Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], ZooState);
    /***/
  },

  /***/
  "./src/app/shared/states/zoo-state/zoo-state.index.ts":
  /*!************************************************************!*\
    !*** ./src/app/shared/states/zoo-state/zoo-state.index.ts ***!
    \************************************************************/

  /*! exports provided: ZooDuty, ZOO_STATE_TOKEN, ZooState */

  /***/
  function srcAppSharedStatesZooStateZooStateIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./actions */
    "./src/app/shared/states/zoo-state/actions.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooDuty", function () {
      return _actions__WEBPACK_IMPORTED_MODULE_1__["ZooDuty"];
    });
    /* harmony import */


    var _state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./state */
    "./src/app/shared/states/zoo-state/state.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZOO_STATE_TOKEN", function () {
      return _state__WEBPACK_IMPORTED_MODULE_2__["ZOO_STATE_TOKEN"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ZooState", function () {
      return _state__WEBPACK_IMPORTED_MODULE_2__["ZooState"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/index.ts":
  /*!*************************************!*\
    !*** ./src/app/zNest/core/index.ts ***!
    \*************************************/

  /*! exports provided: NestFilterPipe, MapModalComponent, LocationPickerPresenter, CallMakerService, FirestoreCrudService, GoogleMapsService, ToastService, SqliteStorageService, TmplDataGridComponent, TmplFormComponent, TmplDetailViewComponent, nestSlideAnimation, NestNumRangeValidator */

  /***/
  function srcAppZNestCoreIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _pipes_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./pipes/index */
    "./src/app/zNest/core/pipes/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "NestFilterPipe", function () {
      return _pipes_index__WEBPACK_IMPORTED_MODULE_1__["NestFilterPipe"];
    });
    /* harmony import */


    var _presenters_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./presenters/index */
    "./src/app/zNest/core/presenters/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "MapModalComponent", function () {
      return _presenters_index__WEBPACK_IMPORTED_MODULE_2__["MapModalComponent"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "LocationPickerPresenter", function () {
      return _presenters_index__WEBPACK_IMPORTED_MODULE_2__["LocationPickerPresenter"];
    });
    /* harmony import */


    var _services_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./services/index */
    "./src/app/zNest/core/services/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CallMakerService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_3__["CallMakerService"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "FirestoreCrudService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_3__["FirestoreCrudService"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "GoogleMapsService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_3__["GoogleMapsService"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_3__["ToastService"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "SqliteStorageService", function () {
      return _services_index__WEBPACK_IMPORTED_MODULE_3__["SqliteStorageService"];
    });
    /* harmony import */


    var _templates_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./templates/index */
    "./src/app/zNest/core/templates/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplDataGridComponent", function () {
      return _templates_index__WEBPACK_IMPORTED_MODULE_4__["TmplDataGridComponent"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplFormComponent", function () {
      return _templates_index__WEBPACK_IMPORTED_MODULE_4__["TmplFormComponent"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplDetailViewComponent", function () {
      return _templates_index__WEBPACK_IMPORTED_MODULE_4__["TmplDetailViewComponent"];
    });
    /* harmony import */


    var _utilities_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./utilities/index */
    "./src/app/zNest/core/utilities/index.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "nestSlideAnimation", function () {
      return _utilities_index__WEBPACK_IMPORTED_MODULE_5__["nestSlideAnimation"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "NestNumRangeValidator", function () {
      return _utilities_index__WEBPACK_IMPORTED_MODULE_5__["NestNumRangeValidator"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/pipes/filter.pipe.ts":
  /*!*************************************************!*\
    !*** ./src/app/zNest/core/pipes/filter.pipe.ts ***!
    \*************************************************/

  /*! exports provided: NestFilterPipe */

  /***/
  function srcAppZNestCorePipesFilterPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NestFilterPipe", function () {
      return NestFilterPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var NestFilterPipe =
    /*#__PURE__*/
    function () {
      function NestFilterPipe() {
        _classCallCheck(this, NestFilterPipe);
      }

      _createClass(NestFilterPipe, [{
        key: "transform",
        value: function transform(items, callback) {
          if (!items || !callback) {
            return items;
          }

          return items.filter(function (itm) {
            return callback(itm);
          });
        }
      }]);

      return NestFilterPipe;
    }();

    NestFilterPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'nestFilterPipe'
    })], NestFilterPipe);
    /***/
  },

  /***/
  "./src/app/zNest/core/pipes/index.ts":
  /*!*******************************************!*\
    !*** ./src/app/zNest/core/pipes/index.ts ***!
    \*******************************************/

  /*! exports provided: NestFilterPipe */

  /***/
  function srcAppZNestCorePipesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _filter_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./filter.pipe */
    "./src/app/zNest/core/pipes/filter.pipe.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "NestFilterPipe", function () {
      return _filter_pipe__WEBPACK_IMPORTED_MODULE_1__["NestFilterPipe"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/presenters/index.ts":
  /*!************************************************!*\
    !*** ./src/app/zNest/core/presenters/index.ts ***!
    \************************************************/

  /*! exports provided: MapModalComponent, LocationPickerPresenter */

  /***/
  function srcAppZNestCorePresentersIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _location_picker_map_modal_map_modal_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./location-picker/map-modal/map-modal.component */
    "./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "MapModalComponent", function () {
      return _location_picker_map_modal_map_modal_component__WEBPACK_IMPORTED_MODULE_1__["MapModalComponent"];
    });
    /* harmony import */


    var _location_picker_location_picker_presenter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./location-picker/location-picker.presenter */
    "./src/app/zNest/core/presenters/location-picker/location-picker.presenter.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "LocationPickerPresenter", function () {
      return _location_picker_location_picker_presenter__WEBPACK_IMPORTED_MODULE_2__["LocationPickerPresenter"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/presenters/location-picker/location-picker.presenter.scss":
  /*!**************************************************************************************!*\
    !*** ./src/app/zNest/core/presenters/location-picker/location-picker.presenter.scss ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppZNestCorePresentersLocationPickerLocationPickerPresenterScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".picker {\n  width: 30rem;\n  max-width: 80%;\n  height: 20rem;\n  max-height: 30vh;\n  border: 1px solid var(--ion-color-primary);\n  margin: auto;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n\n.location-image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvek5lc3QvY29yZS9wcmVzZW50ZXJzL2xvY2F0aW9uLXBpY2tlci9GOlxcUHJvamVjdHNcXE15IFByb2plY3RzXFxNb2JpbGVBcHBcXFN3aWZ0XFxzd2lmdC1jbGllbnQvc3JjXFxhcHBcXHpOZXN0XFxjb3JlXFxwcmVzZW50ZXJzXFxsb2NhdGlvbi1waWNrZXJcXGxvY2F0aW9uLXBpY2tlci5wcmVzZW50ZXIuc2NzcyIsInNyYy9hcHAvek5lc3QvY29yZS9wcmVzZW50ZXJzL2xvY2F0aW9uLXBpY2tlci9sb2NhdGlvbi1waWNrZXIucHJlc2VudGVyLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLDBDQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3pOZXN0L2NvcmUvcHJlc2VudGVycy9sb2NhdGlvbi1waWNrZXIvbG9jYXRpb24tcGlja2VyLnByZXNlbnRlci5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBpY2tlciB7XG4gIHdpZHRoOiAzMHJlbTtcbiAgbWF4LXdpZHRoOiA4MCU7XG4gIGhlaWdodDogMjByZW07XG4gIG1heC1oZWlnaHQ6IDMwdmg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgbWFyZ2luOiBhdXRvO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmxvY2F0aW9uLWltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4iLCIucGlja2VyIHtcbiAgd2lkdGg6IDMwcmVtO1xuICBtYXgtd2lkdGg6IDgwJTtcbiAgaGVpZ2h0OiAyMHJlbTtcbiAgbWF4LWhlaWdodDogMzB2aDtcbiAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBtYXJnaW46IGF1dG87XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4ubG9jYXRpb24taW1hZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/zNest/core/presenters/location-picker/location-picker.presenter.ts":
  /*!************************************************************************************!*\
    !*** ./src/app/zNest/core/presenters/location-picker/location-picker.presenter.ts ***!
    \************************************************************************************/

  /*! exports provided: LocationPickerPresenter */

  /***/
  function srcAppZNestCorePresentersLocationPickerLocationPickerPresenterTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LocationPickerPresenter", function () {
      return LocationPickerPresenter;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var _map_modal_map_modal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./map-modal/map-modal.component */
    "./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.ts");
    /* harmony import */


    var _nest_core_services__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @nest/core/services */
    "./src/app/zNest/core/services/index.ts");
    /* harmony import */


    var _app_main_shared__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @app_main/shared */
    "./src/app/shared/index.ts");

    var LocationPickerPresenter =
    /*#__PURE__*/
    function () {
      function LocationPickerPresenter(modalCtrl, actionSheetCtrl, alertCtrl, mainAppSvc, googleMapsSvc) {
        _classCallCheck(this, LocationPickerPresenter);

        this.modalCtrl = modalCtrl;
        this.actionSheetCtrl = actionSheetCtrl;
        this.alertCtrl = alertCtrl;
        this.mainAppSvc = mainAppSvc;
        this.googleMapsSvc = googleMapsSvc;
        this.locationPick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.isLoading = false;
      }

      _createClass(LocationPickerPresenter, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onPickLocation",
        value: function onPickLocation() {
          var _this9 = this;

          this.actionSheetCtrl.create({
            header: 'Please Choose',
            buttons: [{
              text: 'Auto-Locate',
              handler: function handler() {
                _this9.locateUser();
              }
            }, {
              text: 'Pick on Map',
              handler: function handler() {
                _this9.openMap();
              }
            }, {
              text: 'Cancel',
              role: 'cancel'
            }]
          }).then(function (actionSheetEl) {
            actionSheetEl.present();
          });
        }
      }, {
        key: "locateUser",
        value: function locateUser() {
          var _this10 = this;

          if (this.mainAppSvc.offlineMode) this.locationPick.emit({
            lat: 0,
            lng: 0,
            address: null,
            staticMapImageUrl: '../../assets/madison.jpg'
          });

          if (!_capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Capacitor"].isPluginAvailable('Geolocation')) {
            this.showErrorAlert();
            return;
          }

          this.isLoading = true;

          _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Geolocation.getCurrentPosition().then(function (geoPosition) {
            var coordinates = {
              lat: geoPosition.coords.latitude,
              lng: geoPosition.coords.longitude
            };

            _this10.getPickedLocation(coordinates);

            _this10.isLoading = false;
          }).catch(function (err) {
            _this10.isLoading = false;

            _this10.showErrorAlert();
          });
        }
      }, {
        key: "openMap",
        value: function openMap() {
          var _this11 = this;

          this.modalCtrl.create({
            component: _map_modal_map_modal_component__WEBPACK_IMPORTED_MODULE_6__["MapModalComponent"]
          }).then(function (modalEl) {
            modalEl.onDidDismiss().then(function (modalData) {
              if (_this11.mainAppSvc.offlineMode) _this11.locationPick.emit({
                lat: 0,
                lng: 0,
                address: null,
                staticMapImageUrl: '../../assets/madison.jpg'
              });

              if (!modalData.data) {
                return;
              }

              var coordinates = {
                lat: modalData.data.lat,
                lng: modalData.data.lng
              };

              _this11.getPickedLocation(coordinates);
            });
            modalEl.present();
          });
        }
      }, {
        key: "getPickedLocation",
        value: function getPickedLocation(coords) {
          var _this12 = this;

          var withImage = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
          var pickedLocation = {
            lat: coords.lat,
            lng: coords.lng,
            address: null,
            staticMapImageUrl: null
          };
          this.isLoading = true;
          this.googleMapsSvc.getAddress(coords).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (address) {
            pickedLocation.address = address;
            if (withImage) return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(_this12.googleMapsSvc.getMapImage(coords));else {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
            }
          })).subscribe(function (staticMapImageUrl) {
            pickedLocation.staticMapImageUrl = staticMapImageUrl;
            _this12.selectedLocationImage = staticMapImageUrl;
            _this12.isLoading = false;

            _this12.locationPick.emit(pickedLocation);
          });
        }
      }, {
        key: "showErrorAlert",
        value: function showErrorAlert() {
          this.alertCtrl.create({
            header: 'Could not fetch location',
            message: 'Please use the map to pick a location!',
            buttons: ['Okay']
          }).then(function (alertEl) {
            return alertEl.present();
          });
        }
      }]);

      return LocationPickerPresenter;
    }();

    LocationPickerPresenter.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _app_main_shared__WEBPACK_IMPORTED_MODULE_8__["MainAppService"]
      }, {
        type: _nest_core_services__WEBPACK_IMPORTED_MODULE_7__["GoogleMapsService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], LocationPickerPresenter.prototype, "locationPick", void 0);
    LocationPickerPresenter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-location-picker',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./location-picker.presenter.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/location-picker.presenter.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./location-picker.presenter.scss */
      "./src/app/zNest/core/presenters/location-picker/location-picker.presenter.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _app_main_shared__WEBPACK_IMPORTED_MODULE_8__["MainAppService"], _nest_core_services__WEBPACK_IMPORTED_MODULE_7__["GoogleMapsService"]])], LocationPickerPresenter);
    /***/
  },

  /***/
  "./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.scss":
  /*!******************************************************************************************!*\
    !*** ./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.scss ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppZNestCorePresentersLocationPickerMapModalMapModalComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".map {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  background-color: transparent;\n  opacity: 0;\n  -webkit-transition: opacity 150ms ease-in;\n  transition: opacity 150ms ease-in;\n}\n\n.map.visible {\n  opacity: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvek5lc3QvY29yZS9wcmVzZW50ZXJzL2xvY2F0aW9uLXBpY2tlci9tYXAtbW9kYWwvRjpcXFByb2plY3RzXFxNeSBQcm9qZWN0c1xcTW9iaWxlQXBwXFxTd2lmdFxcc3dpZnQtY2xpZW50L3NyY1xcYXBwXFx6TmVzdFxcY29yZVxccHJlc2VudGVyc1xcbG9jYXRpb24tcGlja2VyXFxtYXAtbW9kYWxcXG1hcC1tb2RhbC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvek5lc3QvY29yZS9wcmVzZW50ZXJzL2xvY2F0aW9uLXBpY2tlci9tYXAtbW9kYWwvbWFwLW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUVBLDZCQUFBO0VBRUEsVUFBQTtFQUNBLHlDQUFBO0VBQUEsaUNBQUE7QUNERjs7QURJQTtFQUNFLFVBQUE7QUNERiIsImZpbGUiOiJzcmMvYXBwL3pOZXN0L2NvcmUvcHJlc2VudGVycy9sb2NhdGlvbi1waWNrZXIvbWFwLW1vZGFsL21hcC1tb2RhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXAge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG5cbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG5cbiAgb3BhY2l0eTogMDtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAxNTBtcyBlYXNlLWluO1xufVxuXG4ubWFwLnZpc2libGUge1xuICBvcGFjaXR5OiAxO1xufVxuIiwiLm1hcCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIG9wYWNpdHk6IDA7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMTUwbXMgZWFzZS1pbjtcbn1cblxuLm1hcC52aXNpYmxlIHtcbiAgb3BhY2l0eTogMTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.ts":
  /*!****************************************************************************************!*\
    !*** ./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.ts ***!
    \****************************************************************************************/

  /*! exports provided: MapModalComponent */

  /***/
  function srcAppZNestCorePresentersLocationPickerMapModalMapModalComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MapModalComponent", function () {
      return MapModalComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _nest_core_services_google_maps_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @nest/core/services/google-maps.service */
    "./src/app/zNest/core/services/google-maps.service.ts");
    /**
     * TODO: use Angular Google maps component
     *
     */


    var MapModalComponent =
    /*#__PURE__*/
    function () {
      function MapModalComponent(modalCtrl, renderer, googleMapsSvc) {
        _classCallCheck(this, MapModalComponent);

        this.modalCtrl = modalCtrl;
        this.renderer = renderer;
        this.googleMapsSvc = googleMapsSvc;
        this.center = {
          lat: -34.397,
          lng: 150.644
        };
        this.selectable = true;
        this.closeButtonText = 'Cancel';
        this.title = 'Pick Location';
      }

      _createClass(MapModalComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var _this13 = this;

          this.googleMapsSvc.getMaps().then(function (googleMaps) {
            _this13.googleMaps = googleMaps;
            var mapEl = _this13.mapElementRef.nativeElement;
            var map = new googleMaps.Map(mapEl, {
              center: _this13.center,
              zoom: 16
            });

            _this13.googleMaps.event.addListenerOnce(map, 'idle', function () {
              _this13.renderer.addClass(mapEl, 'visible');
            });

            if (_this13.selectable) {
              _this13.clickListener = map.addListener('click', function (event) {
                var selectedCoords = {
                  lat: event.latLng.lat(),
                  lng: event.latLng.lng()
                };

                _this13.modalCtrl.dismiss(selectedCoords);
              });
            } else {
              var marker = new googleMaps.Marker({
                position: _this13.center,
                map: map,
                title: 'Picked Location'
              });
              marker.setMap(map);
            }
          }).catch(function (err) {
            console.log(err);
          });
        }
      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.clickListener) {
            this.googleMaps.event.removeListener(this.clickListener);
          }
        }
      }]);

      return MapModalComponent;
    }();

    MapModalComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]
      }, {
        type: _nest_core_services_google_maps_service__WEBPACK_IMPORTED_MODULE_3__["GoogleMapsService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('map', {
      read: true,
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], MapModalComponent.prototype, "mapElementRef", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], MapModalComponent.prototype, "center", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], MapModalComponent.prototype, "selectable", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], MapModalComponent.prototype, "closeButtonText", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], MapModalComponent.prototype, "title", void 0);
    MapModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-map-modal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./map-modal.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./map-modal.component.scss */
      "./src/app/zNest/core/presenters/location-picker/map-modal/map-modal.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _nest_core_services_google_maps_service__WEBPACK_IMPORTED_MODULE_3__["GoogleMapsService"]])], MapModalComponent);
    /***/
  },

  /***/
  "./src/app/zNest/core/services/call-maker.service.ts":
  /*!***********************************************************!*\
    !*** ./src/app/zNest/core/services/call-maker.service.ts ***!
    \***********************************************************/

  /*! exports provided: CallMakerService */

  /***/
  function srcAppZNestCoreServicesCallMakerServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CallMakerService", function () {
      return CallMakerService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic-native/call-number/ngx */
    "./node_modules/@ionic-native/call-number/ngx/index.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CallMakerService =
    /*#__PURE__*/
    function () {
      function CallMakerService(callNumber) {
        _classCallCheck(this, CallMakerService);

        this.callNumber = callNumber;
      }

      _createClass(CallMakerService, [{
        key: "onMakeACall",
        value: function onMakeACall(telNumber) {
          this.callNumber.callNumber(telNumber, true).then(function (res) {
            return console.log('Launched dialer!', res);
          }).catch(function (err) {
            return console.log('Error launching dialer', err);
          });
        }
      }]);

      return CallMakerService;
    }();

    CallMakerService.ctorParameters = function () {
      return [{
        type: _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_1__["CallNumber"]
      }];
    };

    CallMakerService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_1__["CallNumber"]])], CallMakerService);
    /***/
  },

  /***/
  "./src/app/zNest/core/services/firestore-crud.service.ts":
  /*!***************************************************************!*\
    !*** ./src/app/zNest/core/services/firestore-crud.service.ts ***!
    \***************************************************************/

  /*! exports provided: FirestoreCrudService */

  /***/
  function srcAppZNestCoreServicesFirestoreCrudServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FirestoreCrudService", function () {
      return FirestoreCrudService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js");

    var FirestoreCrudService =
    /*#__PURE__*/
    function () {
      function FirestoreCrudService(firestore) {
        _classCallCheck(this, FirestoreCrudService);

        this.firestore = firestore;
      }

      _createClass(FirestoreCrudService, [{
        key: "create",
        value: function create(collectionName, record) {
          return this.firestore.collection(collectionName).add(record);
        }
      }, {
        key: "read",
        value: function read(collectionName) {
          return this.firestore.collection(collectionName).snapshotChanges();
        }
      }, {
        key: "update",
        value: function update(collectionName, recordID, record) {
          this.firestore.doc(collectionName + '/' + recordID).update(record);
        }
      }, {
        key: "delete",
        value: function _delete(collectionName, record_id) {
          this.firestore.doc(collectionName + '/' + record_id).delete();
        }
      }]);

      return FirestoreCrudService;
    }();

    FirestoreCrudService.ctorParameters = function () {
      return [{
        type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]
      }];
    };

    FirestoreCrudService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]])], FirestoreCrudService);
    /***/
  },

  /***/
  "./src/app/zNest/core/services/google-maps.service.ts":
  /*!************************************************************!*\
    !*** ./src/app/zNest/core/services/google-maps.service.ts ***!
    \************************************************************/

  /*! exports provided: GoogleMapsService */

  /***/
  function srcAppZNestCoreServicesGoogleMapsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GoogleMapsService", function () {
      return GoogleMapsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _envt_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @envt/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var GoogleMapsService =
    /*#__PURE__*/
    function () {
      function GoogleMapsService(http) {
        _classCallCheck(this, GoogleMapsService);

        this.http = http;
      }

      _createClass(GoogleMapsService, [{
        key: "getMaps",
        value: function getMaps() {
          var win = window;
          var googleModule = win.google;

          if (googleModule && googleModule.maps) {
            return Promise.resolve(googleModule.maps);
          }

          return new Promise(function (resolve, reject) {
            var script = document.createElement('script');
            script.src = "https://maps.googleapis.com/maps/api/js?key=".concat(_envt_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].googleMapsAPIKey);
            script.async = true;
            script.defer = true;
            document.body.appendChild(script);

            script.onload = function () {
              var loadedGoogleModule = win.google;

              if (loadedGoogleModule && loadedGoogleModule.maps) {
                resolve(loadedGoogleModule.maps);
              } else {
                reject('Google maps SDK not available.');
              }
            };
          });
        }
      }, {
        key: "getAddress",
        value: function getAddress(coords) {
          return this.http.get("https://maps.googleapis.com/maps/api/geocode/json?latlng=\n        ".concat(coords.lat, ",").concat(coords.lng, "&key=").concat(_envt_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].googleMapsAPIKey)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (geoData) {
            if (!geoData || !geoData.results || geoData.results.length === 0) {
              return null;
            }

            return geoData.results[0].formatted_address;
          }));
        }
        /**
         * @defaultValues
         *
         * zoom = 14
         * width = 500,
         * height = 300,
         * markerColor = 'red',
         * markerLabel = 'Place',
         * mapType = 'roadmap'
         *
         */

      }, {
        key: "getMapImage",
        value: function getMapImage(coords) {
          var zoom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 14;
          var width = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 500;
          var height = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 300;
          var markerColor = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 'red';
          var markerLabel = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 'Place';
          var mapType = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 'roadmap';
          return "https://maps.googleapis.com/maps/api/staticmap?center=\n    ".concat(coords.lat, ",").concat(coords.lng, "\n    &zoom=").concat(zoom, "\n    &size=").concat(width, "x").concat(height, "\n    &maptype=").concat(mapType, "\n    &markers=color:").concat(markerColor, "%7Clabel:").concat(markerLabel, "%7C").concat(coords.lat, ",").concat(coords.lng, "\n    &key=").concat(_envt_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].googleMapsAPIKey);
        }
      }]);

      return GoogleMapsService;
    }();

    GoogleMapsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }];
    };

    GoogleMapsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])], GoogleMapsService);
    /***/
  },

  /***/
  "./src/app/zNest/core/services/index.ts":
  /*!**********************************************!*\
    !*** ./src/app/zNest/core/services/index.ts ***!
    \**********************************************/

  /*! exports provided: CallMakerService, FirestoreCrudService, GoogleMapsService, ToastService, SqliteStorageService */

  /***/
  function srcAppZNestCoreServicesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _call_maker_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./call-maker.service */
    "./src/app/zNest/core/services/call-maker.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CallMakerService", function () {
      return _call_maker_service__WEBPACK_IMPORTED_MODULE_1__["CallMakerService"];
    });
    /* harmony import */


    var _firestore_crud_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./firestore-crud.service */
    "./src/app/zNest/core/services/firestore-crud.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "FirestoreCrudService", function () {
      return _firestore_crud_service__WEBPACK_IMPORTED_MODULE_2__["FirestoreCrudService"];
    });
    /* harmony import */


    var _google_maps_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./google-maps.service */
    "./src/app/zNest/core/services/google-maps.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "GoogleMapsService", function () {
      return _google_maps_service__WEBPACK_IMPORTED_MODULE_3__["GoogleMapsService"];
    });
    /* harmony import */


    var _toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./toast.service */
    "./src/app/zNest/core/services/toast.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return _toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"];
    });
    /* harmony import */


    var _sqlite_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./sqlite-storage.service */
    "./src/app/zNest/core/services/sqlite-storage.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "SqliteStorageService", function () {
      return _sqlite_storage_service__WEBPACK_IMPORTED_MODULE_5__["SqliteStorageService"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/services/sqlite-storage.service.ts":
  /*!***************************************************************!*\
    !*** ./src/app/zNest/core/services/sqlite-storage.service.ts ***!
    \***************************************************************/

  /*! exports provided: SqliteStorageService */

  /***/
  function srcAppZNestCoreServicesSqliteStorageServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SqliteStorageService", function () {
      return SqliteStorageService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var capacitor_data_storage_sqlite__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! capacitor-data-storage-sqlite */
    "./node_modules/capacitor-data-storage-sqlite/dist/esm/index.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * add this to MainActivity file for Android
     * import com.jeep.plugin.capacitor.CapacitorDataStorageSqlite;
    
     ...
    
     public class MainActivity extends BridgeActivity {
       @Override
       public void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedngInstanceState);
    
         // Initializes the Bridge
         this.init(savedInstanceState, new ArrayList<Class<? extends Plugin>>() {{
           // Additional plugins you've installed go here
           // Ex: add(TotallyAwesomePlugin.class);
           add(CapacitorDataStorageSqlite.class);
         }});
       }
     }
     */


    var _capacitor_core__WEBP = _capacitor_core__WEBPACK_IMPORTED_MODULE_1__["Plugins"],
        CapacitorDataStorageSqlite = _capacitor_core__WEBP.CapacitorDataStorageSqlite,
        Device = _capacitor_core__WEBP.Device;

    var SqliteStorageService =
    /*#__PURE__*/
    function () {
      function SqliteStorageService() {
        _classCallCheck(this, SqliteStorageService);

        this.storage = {};
        this.init();
      }

      _createClass(SqliteStorageService, [{
        key: "init",
        value: function init() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee() {
            var info;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return Device.getInfo();

                  case 2:
                    info = _context.sent;
                    console.log('platform ', info.platform);

                    if (info.platform === "ios" || info.platform === "android") {
                      this.storage = CapacitorDataStorageSqlite;
                    } else if (info.platform === "electron") {
                      this.storage = capacitor_data_storage_sqlite__WEBPACK_IMPORTED_MODULE_2__["CapacitorDataStorageSqliteElectron"];
                    } else {
                      this.storage = capacitor_data_storage_sqlite__WEBPACK_IMPORTED_MODULE_2__["CapacitorDataStorageSqlite"];
                    }

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "openStore",
        value: function openStore(options) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee2() {
            var _ref, result;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.storage.openStore(options);

                  case 2:
                    _ref = _context2.sent;
                    result = _ref.result;
                    return _context2.abrupt("return", result);

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "setTable",
        value: function setTable(table) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee3() {
            var _ref2, result, message;

            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.storage.setTable(table);

                  case 2:
                    _ref2 = _context3.sent;
                    result = _ref2.result;
                    message = _ref2.message;
                    return _context3.abrupt("return", Promise.resolve([result, message]));

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "setItem",
        value: function setItem(key, value) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.storage.set({
                      key: key,
                      value: value
                    });

                  case 2:
                    return _context4.abrupt("return");

                  case 3:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "getItem",
        value: function getItem(key) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee5() {
            var _ref3, value;

            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.storage.get({
                      key: key
                    });

                  case 2:
                    _ref3 = _context5.sent;
                    value = _ref3.value;
                    return _context5.abrupt("return", value);

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "getAllKeys",
        value: function getAllKeys() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee6() {
            var _ref4, keys;

            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.storage.keys();

                  case 2:
                    _ref4 = _context6.sent;
                    keys = _ref4.keys;
                    return _context6.abrupt("return", keys);

                  case 5:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "removeItem",
        value: function removeItem(key) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee7() {
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.storage.remove({
                      key: key
                    });

                  case 2:
                    return _context7.abrupt("return");

                  case 3:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "clear",
        value: function clear() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee8() {
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    _context8.next = 2;
                    return this.storage.clear();

                  case 2:
                    return _context8.abrupt("return");

                  case 3:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "deleteStore",
        value: function deleteStore(options) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee9() {
            var _ref5, result;

            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    _context9.next = 2;
                    return this.init();

                  case 2:
                    _context9.next = 4;
                    return this.storage.deleteStore(options);

                  case 4:
                    _ref5 = _context9.sent;
                    result = _ref5.result;
                    return _context9.abrupt("return", result);

                  case 7:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }]);

      return SqliteStorageService;
    }();

    SqliteStorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], SqliteStorageService);

    function testPluginWithWrapper() {
      return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee10() {
        var ret1, ret2, ret3, ret4, ret5, ret6, result, value, keys, statusTable;
        return regeneratorRuntime.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                this.storage = new SqliteStorageService();
                ret1 = false;
                ret2 = false;
                ret3 = false;
                ret4 = false;
                ret5 = false;
                ret6 = false;
                _context10.next = 9;
                return this.storage.openStore({});

              case 9:
                result = _context10.sent;

                if (!result) {
                  _context10.next = 53;
                  break;
                }

                _context10.next = 13;
                return this.storage.clear();

              case 13:
                _context10.next = 15;
                return this.storage.setItem("key-test", "This is a test");

              case 15:
                _context10.next = 17;
                return this.storage.getItem("key-test");

              case 17:
                value = _context10.sent;
                if (value === "This is a test") ret1 = true;
                _context10.next = 21;
                return this.storage.getAllKeys();

              case 21:
                keys = _context10.sent;
                if (keys[0] === "key-test") ret2 = true;
                _context10.next = 25;
                return this.storage.removeItem("key-test");

              case 25:
                _context10.next = 27;
                return this.storage.getAllKeys();

              case 27:
                keys = _context10.sent;
                if (keys.length === 0) ret3 = true;
                _context10.next = 31;
                return this.storage.openStore({
                  database: "testStore",
                  table: "table1"
                });

              case 31:
                result = _context10.sent;

                if (!result) {
                  _context10.next = 53;
                  break;
                }

                _context10.next = 35;
                return this.storage.clear();

              case 35:
                _context10.next = 37;
                return this.storage.setItem("key1-test", "This is a new store");

              case 37:
                _context10.next = 39;
                return this.storage.getItem("key1-test");

              case 39:
                value = _context10.sent;
                if (value === "This is a new store") ret4 = true;
                _context10.next = 43;
                return this.storage.setTable({
                  table: "table2"
                });

              case 43:
                statusTable = _context10.sent;
                if (statusTable[0]) ret5 = true;
                _context10.next = 47;
                return this.storage.clear();

              case 47:
                _context10.next = 49;
                return this.storage.setItem("key2-test", "This is a second table");

              case 49:
                _context10.next = 51;
                return this.storage.getItem("key2-test");

              case 51:
                value = _context10.sent;
                if (value === "This is a second table") ret6 = true;

              case 53:
                if (ret1 && ret2 && ret3 && ret4 && ret5 && ret6) {
                  console.log('testPlugin2 is successful');
                }

              case 54:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));
    }
    /***/

  },

  /***/
  "./src/app/zNest/core/services/toast.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/zNest/core/services/toast.service.ts ***!
    \******************************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppZNestCoreServicesToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService =
    /*#__PURE__*/
    function () {
      function ToastService(_toastCtrl) {
        _classCallCheck(this, ToastService);

        this._toastCtrl = _toastCtrl;
      }

      _createClass(ToastService, [{
        key: "showSuccess",
        value: function showSuccess() {
          var _ref6 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
              msg = _ref6.msg,
              title = _ref6.title,
              position = _ref6.position,
              color = _ref6.color;

          if (!title) title = "Successful";
          if (!position) position = "top";
          if (!color) color = "success";

          this._toastCtrl.create({
            header: title,
            message: msg,
            color: color,
            buttons: ['OK'],
            position: position,
            cssClass: position == "top" ? "toast-custom-top-style" : "",
            duration: 2500,
            animated: true,
            keyboardClose: true,
            id: Math.random().toString()
          }).then(function (t) {
            return t.present();
          });
        }
      }, {
        key: "showWarning",
        value: function showWarning() {
          var _ref7 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
              msg = _ref7.msg,
              title = _ref7.title,
              position = _ref7.position,
              color = _ref7.color;

          if (!title) title = "Warning";
          if (!position) position = "top";
          if (!color) color = "warning";

          this._toastCtrl.create({
            header: title,
            message: msg,
            color: color,
            buttons: ['OK'],
            position: position,
            cssClass: position == "top" ? "toast-custom-top-style" : "",
            duration: 2500,
            animated: true,
            keyboardClose: true,
            id: Math.random().toString()
          }).then(function (t) {
            return t.present();
          });
        }
      }, {
        key: "showError",
        value: function showError() {
          var _ref8 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
              msg = _ref8.msg,
              title = _ref8.title,
              position = _ref8.position,
              color = _ref8.color;

          if (!title) title = "Attention";
          if (!position) position = "top";
          if (!color) color = "danger";

          this._toastCtrl.create({
            header: title,
            message: msg,
            color: color,
            buttons: ['OK'],
            position: position,
            cssClass: position == "top" ? "toast-custom-top-style" : "",
            duration: 2500,
            animated: true,
            keyboardClose: true,
            id: Math.random().toString()
          }).then(function (t) {
            return t.present();
          });
        }
      }, {
        key: "showInfo",
        value: function showInfo() {
          var _ref9 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
              msg = _ref9.msg,
              title = _ref9.title,
              position = _ref9.position,
              color = _ref9.color;

          if (!title) title = "Information";
          if (!position) position = "top";
          if (!color) color = "secondary";

          this._toastCtrl.create({
            header: title,
            message: msg,
            color: color,
            buttons: ['OK'],
            position: position,
            cssClass: position == "top" ? "toast-custom-top-style" : "",
            duration: 2500,
            animated: true,
            keyboardClose: true,
            id: Math.random().toString()
          }).then(function (t) {
            return t.present();
          });
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  },

  /***/
  "./src/app/zNest/core/templates/data-grid/tmpl-grid.ts":
  /*!*************************************************************!*\
    !*** ./src/app/zNest/core/templates/data-grid/tmpl-grid.ts ***!
    \*************************************************************/

  /*! exports provided: TmplDataGridComponent */

  /***/
  function srcAppZNestCoreTemplatesDataGridTmplGridTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TmplDataGridComponent", function () {
      return TmplDataGridComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _nest_nest_statics__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @nest/nest-statics */
    "./src/app/zNest/nest-statics.ts");

    var TmplDataGridComponent =
    /*#__PURE__*/
    function () {
      function TmplDataGridComponent() {
        _classCallCheck(this, TmplDataGridComponent);

        this.rows = null;
        this.paginator = null;
        this.pageLinks = null;
        this.rowsPerPageOptions = null;
        this.selectionMode = null;
        this.resizableColumns = null;
        this.onRowSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onRowUnselected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onFieldClicked = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.showSearchRow = false;
        this.dataTable = {
          tableCaption: "",
          value: [],
          columns: [],
          rows: 10,
          paginator: true,
          pageLinks: 3,
          totalRecords: 0,
          rowsPerPageOptions: [5, 10, 20, 50, 100],
          selectionMode: "single",
          selectedRowData: {},
          resizableColumns: true,
          sortableRowGroup: true
        };
        this.columnTemplate = {
          field: "",
          header: "",
          footer: "",
          sortable: true,
          editable: false,
          filter: true,
          filterMatchMode: "",
          rowspan: 1,
          colspan: 1,
          style: {},
          styleClass: "",
          hidden: false,
          expander: false,
          filterPlaceholder: "",
          frozen: false
        };
      }

      _createClass(TmplDataGridComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log("datatable component init.");
        }
      }, {
        key: "ngOnChanges",
        value: function ngOnChanges() {
          this.dataTable.value = this.value;
          this.dataTable.tableCaption = this.tableCaption;
          this.dataTable.columns = this.columns;
          this.dataTable.totalRecords = _nest_nest_statics__WEBPACK_IMPORTED_MODULE_2__["PageOptions"].totalCount;
          if (this.rows != null) this.dataTable.rows = this.rows;
          if (this.paginator != null) this.dataTable.paginator = this.paginator;
          if (this.pageLinks != null) this.dataTable.pageLinks = this.pageLinks;
          if (this.rowsPerPageOptions != null) this.dataTable.rowsPerPageOptions = this.rowsPerPageOptions;
          if (this.selectionMode != null) this.dataTable.selectionMode = this.selectionMode;
          if (this.resizableColumns != null) this.dataTable.resizableColumns = this.resizableColumns;
        }
      }, {
        key: "onRowSelect",
        value: function onRowSelect(event, template) {
          this.selectedRowData = event.data;
          this.onRowSelected.emit(event.data);
          console.log("selected row: " + JSON.stringify(this.selectedRowData));
        }
      }, {
        key: "onRowUnselect",
        value: function onRowUnselect(event) {
          this.selectedRowData = event.data;
          this.onRowUnselected.emit(event.data);
          console.log("unselected row: " + JSON.stringify(this.selectedRowData));
        }
      }, {
        key: "onViewDetail",
        value: function onViewDetail(field, rowData) {
          this.selectedRowData = rowData;
          this.onFieldClicked.emit({
            field: field,
            rowData: rowData
          });
          console.log("selected field: " + field + " rowData: " + JSON.stringify(rowData));
        }
      }, {
        key: "onToggleContextMenu",
        value: function onToggleContextMenu(ctx_menu, event, rowData) {
          this.ctx_btn = event.target.id;
          this.selectedRowData = rowData;

          if (!ctx_menu.visible) {
            this.onRowSelected.emit(this.selectedRowData);
            ctx_menu.show(event);
            event.stopPropagation();
          } else {
            this.onRowUnselected.emit(this.selectedRowData);
            ctx_menu.hide();
          }
        }
      }]);

      return TmplDataGridComponent;
    }();

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], TmplDataGridComponent.prototype, "value", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)], TmplDataGridComponent.prototype, "rows", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], TmplDataGridComponent.prototype, "columns", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)], TmplDataGridComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)], TmplDataGridComponent.prototype, "pageLinks", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], TmplDataGridComponent.prototype, "rowsPerPageOptions", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)], TmplDataGridComponent.prototype, "selectionMode", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], TmplDataGridComponent.prototype, "selectedRowData", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)], TmplDataGridComponent.prototype, "resizableColumns", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)], TmplDataGridComponent.prototype, "tableCaption", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], TmplDataGridComponent.prototype, "onRowSelected", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], TmplDataGridComponent.prototype, "onRowUnselected", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], TmplDataGridComponent.prototype, "onFieldClicked", void 0);
    TmplDataGridComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'tmpl-grid',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tmpl-grid.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/data-grid/tmpl-grid.html")).default
    })], TmplDataGridComponent);
    /***/
  },

  /***/
  "./src/app/zNest/core/templates/form/tmpl-form.scss":
  /*!**********************************************************!*\
    !*** ./src/app/zNest/core/templates/form/tmpl-form.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppZNestCoreTemplatesFormTmplFormScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/*****Nest styles****/\n.nest-form-validation-help-block {\n  color: var(--ion-color-danger);\n  font-size: 12px;\n}\n.nest-form-error {\n  color: var(--ion-color-danger);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvek5lc3QvY29yZS90ZW1wbGF0ZXMvZm9ybS9GOlxcUHJvamVjdHNcXE15IFByb2plY3RzXFxNb2JpbGVBcHBcXFN3aWZ0XFxzd2lmdC1jbGllbnQvc3JjXFxhcHBcXHpOZXN0XFxjb3JlXFx0ZW1wbGF0ZXNcXGZvcm1cXHRtcGwtZm9ybS5zY3NzIiwic3JjL2FwcC96TmVzdC9jb3JlL3RlbXBsYXRlcy9mb3JtL3RtcGwtZm9ybS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFDLHFCQUFBO0FBQ0E7RUFDRyw4QkFBQTtFQUNBLGVBQUE7QUNDSjtBRENLO0VBQ0UsOEJBQUE7QUNFUCIsImZpbGUiOiJzcmMvYXBwL3pOZXN0L2NvcmUvdGVtcGxhdGVzL2Zvcm0vdG1wbC1mb3JtLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgLyoqKioqTmVzdCBzdHlsZXMqKioqL1xyXG4gLm5lc3QtZm9ybS12YWxpZGF0aW9uLWhlbHAtYmxvY2t7XHJcbiAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICB9XHJcbiAgICAgLm5lc3QtZm9ybS1lcnJvclxyXG57ICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XHJcbn0iLCIvKioqKipOZXN0IHN0eWxlcyoqKiovXG4ubmVzdC1mb3JtLXZhbGlkYXRpb24taGVscC1ibG9jayB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgZm9udC1zaXplOiAxMnB4O1xufVxuXG4ubmVzdC1mb3JtLWVycm9yIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/zNest/core/templates/form/tmpl-form.ts":
  /*!********************************************************!*\
    !*** ./src/app/zNest/core/templates/form/tmpl-form.ts ***!
    \********************************************************/

  /*! exports provided: TmplFormComponent */

  /***/
  function srcAppZNestCoreTemplatesFormTmplFormTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TmplFormComponent", function () {
      return TmplFormComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! util */
    "./node_modules/util/util.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_3___default =
    /*#__PURE__*/
    __webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _nest_nest_statics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @nest/nest-statics */
    "./src/app/zNest/nest-statics.ts");
    /* harmony import */


    var underscore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! underscore */
    "./node_modules/underscore/modules/index-all.js");
    /* harmony import */


    var _nest_nest_enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @nest/nest-enums */
    "./src/app/zNest/nest-enums.ts");

    var TmplFormComponent =
    /*#__PURE__*/
    function () {
      function TmplFormComponent(_fb) {
        _classCallCheck(this, TmplFormComponent);

        this._fb = _fb;
        this.submitForm = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this._submitFormTitle = "SAVE";
        this._errMessage = "";
      }

      _createClass(TmplFormComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.nestFormCtrlType = _nest_nest_statics__WEBPACK_IMPORTED_MODULE_4__["FormCtrlType"];
          if (!Object(util__WEBPACK_IMPORTED_MODULE_3__["isNullOrUndefined"])(this.submitFormTitle)) this._submitFormTitle = this.submitFormTitle;
          this._localDataModel = this.dataModel;
          this._localDataModel.fields = underscore__WEBPACK_IMPORTED_MODULE_5__["where"](this.dataModel.fields, {
            formView: true
          });
          this.initCustomerForm();
        }
      }, {
        key: "ngOnChanges",
        value: function ngOnChanges() {
          if (this.formData != null && this._localDataForm != null) {
            this._localDataForm.patchValue(this.formData);
          }
        }
      }, {
        key: "initCustomerForm",
        value: function initCustomerForm() {
          var _this14 = this;

          this._localDataForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({});
          var grp = {};

          this._localDataModel.fields.forEach(function (fld) {
            var frmCtrl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](_this14.setFormCtrlDefaultValue(fld));
            var fieldModel = underscore__WEBPACK_IMPORTED_MODULE_5__["findWhere"](_this14._localDataModel.validators, {
              name: fld.name
            });

            if (fieldModel != null) {
              frmCtrl.setValidators(fieldModel.validationRule);
              frmCtrl.updateValueAndValidity();
            }

            _this14._localDataForm.addControl(fld.name, frmCtrl);
          });

          this._localDataForm.updateValueAndValidity();
        }
      }, {
        key: "setFormCtrlDefaultValue",
        value: function setFormCtrlDefaultValue(fld) {
          switch (fld.dataType) {
            case "bool":
              return true;

            case "select":
              return null;

            default:
              '';
              break;
          }
        }
      }, {
        key: "formSubmit",
        value: function formSubmit() {
          var formValue = this._localDataForm.value;
          console.log('Saved in template: ' + JSON.stringify(formValue));
          if (!this._localDataForm.valid) return;
          this.submitForm.emit(formValue);
        }
      }, {
        key: "filterFormField",
        value: function filterFormField(field) {
          return field.formView == true;
        }
      }, {
        key: "validateForm",
        value: function validateForm(fieldName) {
          var INVALID = false;

          if (this._localDataForm.get(fieldName) && (this._localDataForm.get(fieldName).touched || this._localDataForm.get(fieldName).dirty) && this._localDataForm.get(fieldName).errors) {
            var error = this._localDataForm.get(fieldName).errors;

            INVALID = this.getErrorMessage(error);
          }

          return INVALID;
        }
      }, {
        key: "getErrorMessage",
        value: function getErrorMessage(error) {
          this._errMessage = "";

          if (error.required) {
            this._errMessage = "*Required!";
          } else if (error.pattern) this._errMessage = "*Invalid format!";else if (error.email) {
            this._errMessage = "*Invalid format!(Sample: john@gmail.com)";
          } else if (error.minlength) {
            this._errMessage = "*Minimum length allowed is " + error.minlength.requiredLength + " !";
          } else if (error.numRange) {
            this._errMessage = error.numRange.message;
          } else return false;

          return true;
        }
      }]);

      return TmplFormComponent;
    }();

    TmplFormComponent.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])], TmplFormComponent.prototype, "submitForm", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], TmplFormComponent.prototype, "formData", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)], TmplFormComponent.prototype, "formSubmitType", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], TmplFormComponent.prototype, "dataModel", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)], TmplFormComponent.prototype, "submitFormTitle", void 0);
    TmplFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'tmpl-form',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tmpl-form.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/form/tmpl-form.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tmpl-form.scss */
      "./src/app/zNest/core/templates/form/tmpl-form.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])], TmplFormComponent);
    /***/
  },

  /***/
  "./src/app/zNest/core/templates/index.ts":
  /*!***********************************************!*\
    !*** ./src/app/zNest/core/templates/index.ts ***!
    \***********************************************/

  /*! exports provided: TmplDataGridComponent, TmplFormComponent, TmplDetailViewComponent */

  /***/
  function srcAppZNestCoreTemplatesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _data_grid_tmpl_grid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./data-grid/tmpl-grid */
    "./src/app/zNest/core/templates/data-grid/tmpl-grid.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplDataGridComponent", function () {
      return _data_grid_tmpl_grid__WEBPACK_IMPORTED_MODULE_1__["TmplDataGridComponent"];
    });
    /* harmony import */


    var _form_tmpl_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./form/tmpl-form */
    "./src/app/zNest/core/templates/form/tmpl-form.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplFormComponent", function () {
      return _form_tmpl_form__WEBPACK_IMPORTED_MODULE_2__["TmplFormComponent"];
    });
    /* harmony import */


    var _views_detail_view_tmpl_detail_view__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./views/detail-view/tmpl-detail-view */
    "./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "TmplDetailViewComponent", function () {
      return _views_detail_view_tmpl_detail_view__WEBPACK_IMPORTED_MODULE_3__["TmplDetailViewComponent"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.ts ***!
    \****************************************************************************/

  /*! exports provided: TmplDetailViewComponent */

  /***/
  function srcAppZNestCoreTemplatesViewsDetailViewTmplDetailViewTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TmplDetailViewComponent", function () {
      return TmplDetailViewComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");

    var TmplDetailViewComponent =
    /*#__PURE__*/
    function () {
      function TmplDetailViewComponent(_router, _location) {
        _classCallCheck(this, TmplDetailViewComponent);

        this._router = _router;
        this._location = _location;
        this.onClickButtonAction = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
      }

      _createClass(TmplDetailViewComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onActionSelected",
        value: function onActionSelected(event) {//implement in you extended component
        }
      }, {
        key: "onActionButtonClicked",
        value: function onActionButtonClicked(clickedBtn) {//implement in you extended component
        }
      }, {
        key: "btnActionSelected",
        value: function btnActionSelected(event) {
          this.onClickButtonAction.emit(event);
        }
      }, {
        key: "onNavigateBack",
        value: function onNavigateBack() {
          this._location.back();
        }
      }, {
        key: "onToggleContextMenu",
        value: function onToggleContextMenu(ctx_menu, event) {
          this.ctx_btn = event.target.id;

          if (!ctx_menu.visible) {
            ctx_menu.show(event);
            event.stopPropagation();
          } else {
            ctx_menu.hide();
          }
        }
      }]);

      return TmplDetailViewComponent;
    }();

    TmplDetailViewComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], TmplDetailViewComponent.prototype, "onClickButtonAction", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], TmplDetailViewComponent.prototype, "menuActions", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], TmplDetailViewComponent.prototype, "buttonActions", void 0);
    TmplDetailViewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'tmpl-detail-view',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tmpl-detail-view.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/zNest/core/templates/views/detail-view/tmpl-detail-view.html")).default
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]])], TmplDetailViewComponent);
    /***/
  },

  /***/
  "./src/app/zNest/core/utilities/animators.ts":
  /*!***************************************************!*\
    !*** ./src/app/zNest/core/utilities/animators.ts ***!
    \***************************************************/

  /*! exports provided: nestSlideAnimation */

  /***/
  function srcAppZNestCoreUtilitiesAnimatorsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "nestSlideAnimation", function () {
      return nestSlideAnimation;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/animations */
    "./node_modules/@angular/animations/fesm2015/animations.js");
    /* harmony import */


    var _nest_nest_enums__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @nest/nest-enums */
    "./src/app/zNest/nest-enums.ts");

    function nestSlideAnimation(type) {
      if (type == _nest_nest_enums__WEBPACK_IMPORTED_MODULE_2__["animation"].Slide_From_Bottom) return slideFromBottom();else if (type == _nest_nest_enums__WEBPACK_IMPORTED_MODULE_2__["animation"].Slide_From_Top) return slideFromUp();
    }

    function slideFromBottom() {
      return Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('nestRouterTransition', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('void', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        'padding-top': '20px',
        opacity: '0'
      })), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('*', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        'padding-top': '0px',
        opacity: '1'
      })), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.33s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        opacity: '1',
        'padding-top': '0px'
      }))])]);
    }

    function slideFromUp() {
      return Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('nestRouterTransition', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('void', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        'margin-top': '-10px',
        opacity: '0'
      })), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])('*', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        'margin-top': '0px',
        opacity: '1'
      })), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('0.2s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({
        opacity: '1',
        'margin-top': '0px'
      }))])]);
    }
    /***/

  },

  /***/
  "./src/app/zNest/core/utilities/index.ts":
  /*!***********************************************!*\
    !*** ./src/app/zNest/core/utilities/index.ts ***!
    \***********************************************/

  /*! exports provided: nestSlideAnimation, NestNumRangeValidator */

  /***/
  function srcAppZNestCoreUtilitiesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _animators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./animators */
    "./src/app/zNest/core/utilities/animators.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "nestSlideAnimation", function () {
      return _animators__WEBPACK_IMPORTED_MODULE_1__["nestSlideAnimation"];
    });
    /* harmony import */


    var _validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./validators */
    "./src/app/zNest/core/utilities/validators.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "NestNumRangeValidator", function () {
      return _validators__WEBPACK_IMPORTED_MODULE_2__["NestNumRangeValidator"];
    });
    /***/

  },

  /***/
  "./src/app/zNest/core/utilities/validators.ts":
  /*!****************************************************!*\
    !*** ./src/app/zNest/core/utilities/validators.ts ***!
    \****************************************************/

  /*! exports provided: NestNumRangeValidator */

  /***/
  function srcAppZNestCoreUtilitiesValidatorsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NestNumRangeValidator", function () {
      return NestNumRangeValidator;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! util */
    "./node_modules/util/util.js");
    /* harmony import */


    var util__WEBPACK_IMPORTED_MODULE_1___default =
    /*#__PURE__*/
    __webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_1__);

    function NestNumRangeValidator(minNum, maxNum) {
      return function (control) {
        if (Object(util__WEBPACK_IMPORTED_MODULE_1__["isNullOrUndefined"])(control.value).valueOf() == false) {
          if (Number(control.value) >= minNum && Number(control.value) < maxNum) return null;else return {
            'numRange': {
              minValue: minNum,
              maxValue: maxNum,
              message: "*Number must be between " + minNum.toString() + " and " + maxNum + "!"
            }
          };
        }

        return null;
      };
    }
    /***/

  },

  /***/
  "./src/app/zNest/nest-enums.ts":
  /*!*************************************!*\
    !*** ./src/app/zNest/nest-enums.ts ***!
    \*************************************/

  /*! exports provided: gender, formSubmitType, statusType, animation */

  /***/
  function srcAppZNestNestEnumsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "gender", function () {
      return gender;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "formSubmitType", function () {
      return formSubmitType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "statusType", function () {
      return statusType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "animation", function () {
      return animation;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var gender;

    (function (gender) {
      gender[gender["UNKNOWN"] = 0] = "UNKNOWN";
      gender[gender["MALE"] = 1] = "MALE";
      gender[gender["FEMALE"] = 2] = "FEMALE";
    })(gender || (gender = {}));

    var formSubmitType;

    (function (formSubmitType) {
      formSubmitType[formSubmitType["NEW"] = 0] = "NEW";
      formSubmitType[formSubmitType["UPDATE"] = 1] = "UPDATE";
    })(formSubmitType || (formSubmitType = {}));

    var statusType;

    (function (statusType) {
      statusType[statusType["INACTIVE"] = 0] = "INACTIVE";
      statusType[statusType["ACTIVE"] = 1] = "ACTIVE";
    })(statusType || (statusType = {}));

    var animation;

    (function (animation) {
      animation[animation["Slide_From_Bottom"] = 1] = "Slide_From_Bottom";
      animation[animation["Slide_From_Top"] = 2] = "Slide_From_Top";
    })(animation || (animation = {}));
    /***/

  },

  /***/
  "./src/app/zNest/nest-primeng.module.ts":
  /*!**********************************************!*\
    !*** ./src/app/zNest/nest-primeng.module.ts ***!
    \**********************************************/

  /*! exports provided: NestPrimengModule */

  /***/
  function srcAppZNestNestPrimengModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NestPrimengModule", function () {
      return NestPrimengModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var primeng_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! primeng/toast */
    "./node_modules/primeng/fesm2015/primeng-toast.js");
    /* harmony import */


    var primeng_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! primeng/table */
    "./node_modules/primeng/fesm2015/primeng-table.js");
    /* harmony import */


    var primeng_dropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! primeng/dropdown */
    "./node_modules/primeng/fesm2015/primeng-dropdown.js");
    /* harmony import */


    var primeng__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! primeng */
    "./node_modules/primeng/fesm2015/primeng.js");

    var NestPrimengModule = function NestPrimengModule() {
      _classCallCheck(this, NestPrimengModule);
    };

    NestPrimengModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [primeng__WEBPACK_IMPORTED_MODULE_5__["InputTextModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ButtonModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ConfirmDialogModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["DialogModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["PanelModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["AccordionModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["PasswordModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["SharedModule"], primeng_dropdown__WEBPACK_IMPORTED_MODULE_4__["DropdownModule"], primeng_table__WEBPACK_IMPORTED_MODULE_3__["TableModule"], primeng_toast__WEBPACK_IMPORTED_MODULE_2__["ToastModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["MegaMenuModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["BlockUIModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["CalendarModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ContextMenuModule"]],
      exports: [primeng__WEBPACK_IMPORTED_MODULE_5__["InputTextModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ButtonModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ConfirmDialogModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["DialogModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["PanelModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["AccordionModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["PasswordModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["SharedModule"], primeng_dropdown__WEBPACK_IMPORTED_MODULE_4__["DropdownModule"], primeng_table__WEBPACK_IMPORTED_MODULE_3__["TableModule"], primeng_toast__WEBPACK_IMPORTED_MODULE_2__["ToastModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["MegaMenuModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["BlockUIModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["CalendarModule"], primeng__WEBPACK_IMPORTED_MODULE_5__["ContextMenuModule"]],
      providers: [primeng__WEBPACK_IMPORTED_MODULE_5__["MessageService"]]
    })], NestPrimengModule);
    /***/
  },

  /***/
  "./src/app/zNest/nest-shared.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/zNest/nest-shared.module.ts ***!
    \*********************************************/

  /*! exports provided: NestSharedModule */

  /***/
  function srcAppZNestNestSharedModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NestSharedModule", function () {
      return NestSharedModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _nest_nest_primeng_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @nest/nest-primeng.module */
    "./src/app/zNest/nest-primeng.module.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _nest_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @nest/core */
    "./src/app/zNest/core/index.ts");

    var NestSharedModule = function NestSharedModule() {
      _classCallCheck(this, NestSharedModule);
    };

    NestSharedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _nest_nest_primeng_module__WEBPACK_IMPORTED_MODULE_4__["NestPrimengModule"]],
      declarations: [_nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplDataGridComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplFormComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplDetailViewComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["LocationPickerPresenter"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["MapModalComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["NestFilterPipe"]],
      exports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _nest_nest_primeng_module__WEBPACK_IMPORTED_MODULE_4__["NestPrimengModule"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplDataGridComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplDetailViewComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["TmplFormComponent"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["LocationPickerPresenter"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["MapModalComponent"]],
      providers: [_nest_core__WEBPACK_IMPORTED_MODULE_6__["ToastService"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["FirestoreCrudService"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["GoogleMapsService"], _nest_core__WEBPACK_IMPORTED_MODULE_6__["CallMakerService"]],
      entryComponents: [_nest_core__WEBPACK_IMPORTED_MODULE_6__["MapModalComponent"]]
    })], NestSharedModule);
    /***/
  },

  /***/
  "./src/app/zNest/nest-statics.ts":
  /*!***************************************!*\
    !*** ./src/app/zNest/nest-statics.ts ***!
    \***************************************/

  /*! exports provided: PageOptions, FormCtrlType, RegExValidators */

  /***/
  function srcAppZNestNestStaticsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PageOptions", function () {
      return PageOptions;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FormCtrlType", function () {
      return FormCtrlType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegExValidators", function () {
      return RegExValidators;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var PageOptions = {
      filter: {
        predicate: '',
        value: []
      },
      page: {
        pageSize: 1,
        pageNumber: 1
      },
      sort: {
        property: 'id',
        order: 'ascending'
      },
      totalCount: 0
    };
    var FormCtrlType = {
      INPUT: 'input',
      CHECKBOX: 'checkbox',
      TEXTAREA: 'textarea',
      SELECT: 'select',
      LOCATION: 'location'
    };
    var RegExValidators = {
      ALPHA_SPACE: "[a-zA-Z ]*",
      ALPHA_NUM_SPACE: "[a-zA-Z0-9 ]*",
      ALPHA_NUM: "[a-zA-Z0-9]*",
      ALPHA: "[a-zA-Z]*"
    };
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false,
      firebaseConfig: {
        apiKey: "AIzaSyDHhtyMZ4lj0U7Cpetjo_EO-skPz1rgyjk",
        authDomain: "swift-gariye-16681.firebaseapp.com",
        databaseURL: "https://swift-gariye-16681.firebaseio.com",
        projectId: "swift-gariye-16681",
        storageBucket: "swift-gariye-16681.appspot.com",
        messagingSenderId: "807004301982",
        appId: "1:807004301982:web:0693ea79f77a39847fa98f",
        measurementId: "G-PG57LCH0B7"
      },
      googleMapsAPIKey: ''
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"]).catch(function (err) {
      return console.log(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! F:\Projects\My Projects\MobileApp\Swift\swift-client\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map